﻿using Model;
using PagedList;
using System;
using System.Collections.Generic;

namespace Repository
{
    public interface ITraineeCandidateRepository : IRepository<TraineeCandidate>
    {
        IPagedList<CandidateInfo> Search(string fullName, DateTime? dbo, string phone, string email, int? pageNumber, int? pageSize);
        IPagedList<TraineeCandidate> GetAllPaging(int? page, int? pageSize);

        List<string> GetAllDistintUniversity();
        List<string> GetAllDistintMajor();
    }
}
