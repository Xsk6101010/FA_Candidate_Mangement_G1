﻿using Model;
using PagedList;

namespace Repository
{
    public interface ICandidateRepository : IRepository<Candidate>
    {
        ExistCheckResult IsExist(string email,string phone);

        IPagedList<Candidate> GetAllToPagedList (int pageNumber,int pageSize);

        int GetPagePosition(int id, int pageSize);
    }
}
