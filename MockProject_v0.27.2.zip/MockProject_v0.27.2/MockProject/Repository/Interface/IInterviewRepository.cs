﻿using Model;
using System.Collections.Generic;

namespace Repository
{
    public interface IInterviewRepository : IRepository<Interview>
    {
        List<Interview> GetByCadidateID(int id);
    }
}
