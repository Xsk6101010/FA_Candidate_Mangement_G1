﻿using Model;
using System.Collections.Generic;

namespace Repository
{
    public interface IOfferRepository : IRepository<Offer>
    {
        List<Offer> GetByForeignKeyID(int id);
    }
}
