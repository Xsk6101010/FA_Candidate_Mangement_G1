﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository
{
    public interface IHistoryRepository: IRepository<History>
    {
        History GetByTraineeCandidate(int traineeCandidateID);
    }
}
