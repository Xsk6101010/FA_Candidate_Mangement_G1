﻿using Model;
using System.Collections.Generic;
using System.Linq;

namespace Repository
{
    public class InterviewRepository : IInterviewRepository
    {
        private CandidateContext dbContext;

        public InterviewRepository()
        {
            dbContext = new CandidateContext();
        }
        public int Add(Interview item)
        {
            dbContext.Interviews.Add(item);
            dbContext.SaveChanges();
            return item.InterviewID;
        }

        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.Interviews.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<Interview> GetAll()
        {
            return dbContext.Interviews.ToList();
        }

        public Interview GetByID(int id)
        {
            return dbContext.Interviews.FirstOrDefault(item => item.InterviewID == id);
        }

        public bool Update(Interview item)
        {
            var selected = GetByID(item.InterviewID);
            selected.Time = item.Time;
            selected.Date = item.Date;
            selected.Interviewer = item.Interviewer;
            selected.Comments = item.Comments;
            selected.Result = item.Result;
            selected.Remarks = item.Remarks;
            return dbContext.SaveChanges() > 0;
        }

        public List<Interview> GetByCadidateID(int id)
        {
            return dbContext.Interviews.Where(item => item.CandidateID == id).ToList();
        }
    }
}
