﻿using Model;
using System.Collections.Generic;
using System.Linq;
namespace Repository
{
    public class OfferRepository : IOfferRepository
    {
        private CandidateContext dbContext;

        public OfferRepository()
        {
            dbContext = new CandidateContext();
        }
        public int Add(Offer item)
        {
            dbContext.Offers.Add(item);
            dbContext.SaveChanges();
            return item.OfferID;
        }

        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.Offers.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<Offer> GetAll()
        {
            return dbContext.Offers.ToList();
        }

        public Offer GetByID(int id)
        {
            return dbContext.Offers.FirstOrDefault(offer => offer.OfferID == id);
        }

        public bool Update(Offer item)
        {
            var selected = GetByID(item.OfferID);
            selected.Jobrank = item.Jobrank;
            selected.OfferSalary = item.OfferSalary;
            selected.Technology = item.Technology;
            selected.ContractType = item.ContractType;
            selected.Remarks = item.Remarks;
            return dbContext.SaveChanges() > 0;
        }

        public List<Offer> GetByForeignKeyID(int id)
        {
            return dbContext.Offers.Where(item => item.CandidateID == id).ToList();
        }
    }
}
