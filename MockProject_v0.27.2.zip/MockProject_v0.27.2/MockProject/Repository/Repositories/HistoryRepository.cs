﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Repository
{
    public class HistoryRepository : IHistoryRepository
    {
        private CandidateContext dbContext;

        public HistoryRepository()
        {
            dbContext = new CandidateContext();
        }
        public int Add(History item)
        {
            dbContext.Histories.Add(item);
            dbContext.SaveChanges();
            return item.HistoryID;
        }

        public bool Delete(int id)
        {
            var history = GetByID(id);
            dbContext.Histories.Remove(history);
            return dbContext.SaveChanges() > 0;
        }

        public List<History> GetAll()
        {
            return dbContext.Histories.ToList();
        }

        public History GetByID(int id)
        {
            return dbContext.Histories.FirstOrDefault(history => history.HistoryID == id);
        }

        public History GetByTraineeCandidate(int traineeCandidateID)
        {
            return dbContext.Histories.FirstOrDefault(history => history.TraineeCandidateID == traineeCandidateID);
        }

        public bool Update(History item)
        {
            var history = GetByID(item.HistoryID);
            history.HistoryText = item.HistoryText;
            history.ModifiedDate = item.ModifiedDate;
            history.ModifiedUser = item.ModifiedUser;
            return dbContext.SaveChanges() > 0;
        }
    }
}
