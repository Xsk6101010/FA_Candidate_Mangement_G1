﻿using Model;
using System.Collections.Generic;
using System.Linq;

namespace Repository
{
    public class ChannelRepository : IRepository<Channel>
    {
        private CandidateContext dbContext;

        public ChannelRepository()
        {
            dbContext = new CandidateContext();
        }

        public int Add(Channel item)
        {
            dbContext.Channels.Add(item);
            dbContext.SaveChanges();
            return item.ChannelID;
        }

        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.Channels.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<Channel> GetAll()
        {
            return dbContext.Channels.ToList();
        }

        public Channel GetByID(int id)
        {
            return dbContext.Channels.FirstOrDefault(item => item.ChannelID == id);
        }

        public bool Update(Channel item)
        {
            var selected = GetByID(item.ChannelID);
            selected.ChannelName = item.ChannelName;
            selected.Remarks = item.Remarks;
            return dbContext.SaveChanges() > 0;
        }
    }
}
