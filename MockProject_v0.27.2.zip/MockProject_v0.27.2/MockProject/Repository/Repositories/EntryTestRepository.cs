﻿using System;
using System.Collections.Generic;
using Model;
using System.Linq;

namespace Repository
{
    public class EntryTestRepository : IEntryTestRepository
    {
        private CandidateContext dbContext;

        public EntryTestRepository()
        {
            dbContext = new CandidateContext();
        }
        public int Add(EntryTest item)
        {
            dbContext.EntryTests.Add(item);
            dbContext.SaveChanges();
            return item.EntryTestID;
        }

        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.EntryTests.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<EntryTest> GetAll()
        {
            return dbContext.EntryTests.ToList();
        }

        public EntryTest GetByID(int id)
        {
            return dbContext.EntryTests.FirstOrDefault(item => item.EntryTestID == id);
        }

        public bool Update(EntryTest item)
        {
            var selected = GetByID(item.EntryTestID);
            selected.Time = item.Time;
            selected.LanguageValuator = item.LanguageValuator;
            selected.LanguageResult = item.LanguageResult;
            selected.TechnicalValuator = item.TechnicalValuator;
            selected.TechnicalResult = item.TechnicalResult;
            selected.Result = item.Result;
            selected.Remarks = item.Remarks;
            return dbContext.SaveChanges() > 0;
        }
        
        public List<EntryTest> GetByForeignKeyID(int id)
        {
            return dbContext.EntryTests.Where(item => item.CandidateID == id).ToList();
        }
    }
}
