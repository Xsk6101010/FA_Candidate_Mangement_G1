﻿using System.Collections.Generic;
using System.Linq;
using Model;

namespace Repository
{
    public class ClassBatchRepository : IRepository<ClassBatch>
    {
        private CandidateContext dbContext;

        public ClassBatchRepository()
        {
            dbContext = new CandidateContext();
        }
        public int Add(ClassBatch item)
        {
            dbContext.ClassBatchs.Add(item);
            dbContext.SaveChanges();
            return item.ClassID;
        }

        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.ClassBatchs.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<ClassBatch> GetAll()
        {
            return dbContext.ClassBatchs.ToList();
        }

        public ClassBatch GetByID(int id)
        {
            return dbContext.ClassBatchs.FirstOrDefault(item => item.ClassID == id);
        }

        public bool Update(ClassBatch item)
        {
            var selected = GetByID(item.ClassID);
            selected.ClassName = item.ClassName;
            selected.ClassCode = item.ClassCode;
            return dbContext.SaveChanges() > 0;
        }
    }
}
