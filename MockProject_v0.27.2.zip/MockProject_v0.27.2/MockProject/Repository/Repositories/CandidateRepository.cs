﻿using System;
using System.Collections.Generic;
using System.Linq;
using Model;
using PagedList.Mvc;
using PagedList;

namespace Repository
{
    public class CandidateRepository : ICandidateRepository
    {
        private readonly ITraineeCandidateRepository traineeCandidateRepository;

        private CandidateContext dbContext;
        //public CandidateRepository()
        //{
        //    dbContext = new CandidateContext();
        //}
        public CandidateRepository(ITraineeCandidateRepository traineeCandidateRepository)
        {
            dbContext = new CandidateContext();
            this.traineeCandidateRepository = traineeCandidateRepository;
        }

        public int Add(Candidate candidate)
        {
            using(var transaction = dbContext.Database.BeginTransaction())
            {
                try
                {
                    int candidateID = traineeCandidateRepository.Add(candidate.TraineeCandidate);
                    var newCandidate = new Candidate
                    {
                        CandidateID = candidateID,
                        Status = "New",
                        ChannelID = candidate.ChannelID
                    };
                    dbContext.Candidates.Add(newCandidate);
                    dbContext.SaveChanges();
                    transaction.Commit();
                    return newCandidate.CandidateID;
                }
                catch
                {
                    transaction.Rollback();
                    return -1;
                }
            }
        }
        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.Candidates.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<Candidate> GetAll()
        {
            return dbContext.Candidates.ToList();
        }

        public IPagedList<Candidate> GetAllToPagedList(int pageNumber = 1, int pageSize = 5)
        {
            return dbContext.Candidates.ToList().OrderBy(candidate => candidate.CandidateID).ToPagedList(pageNumber, pageSize);
        }

        public Candidate GetByID(int id)
        {
            return dbContext.Candidates.FirstOrDefault(item => item.CandidateID == id);
        }

        public bool Update(Candidate item)
        {
            var selected = GetByID(item.CandidateID);

            selected.ChannelID = item.ChannelID;
            traineeCandidateRepository.Update(item.TraineeCandidate);
            selected.Status = item.Status;

            return dbContext.SaveChanges() > 0;
        }

        public ExistCheckResult IsExist(string email, string phone)
        {
            bool isEmail = false;
            bool isPhone = false;
            if (dbContext.Candidates.FirstOrDefault(candidate => candidate.TraineeCandidate.Email == email) != null)
            {
                isEmail = true;
            }
            if (dbContext.Candidates.FirstOrDefault(candidate => candidate.TraineeCandidate.Phone == phone) != null)
            {
                isPhone = true;
            }
            return (new ExistCheckResult{isEmailExisted = isEmail,isPhoneExisted = isPhone});
        }

        public int GetPagePosition(int id,int pageSize)
        {
            var listCandidate = dbContext.Candidates.ToList();
            double position = listCandidate.FindIndex(candidate => candidate.CandidateID == id);
            int page = (int)Math.Ceiling((position+1)/pageSize);
            return page;
        }
    }
}

public class ExistCheckResult
{
    public bool isEmailExisted { get; set; }
    public bool isPhoneExisted { get; set; }
}
