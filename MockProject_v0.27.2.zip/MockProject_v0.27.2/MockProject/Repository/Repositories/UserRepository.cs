﻿using System.Collections.Generic;
using System.Linq;
using Model;

namespace Repository
{
    public class UserRepository : IUserRepository
    {
        private CandidateContext dbContext;
        public UserRepository()
        {
            dbContext = new CandidateContext();
        }
        public string Add(User item)
        {
            dbContext.Users.Add(item);
            dbContext.SaveChanges();
            return item.Username;
        }

        public User CheckLogin(string username, string password)
        {
            return dbContext.Users.FirstOrDefault(user => user.Username == username && user.Password == password);
        }

        public bool Delete(string id)
        {
            var item = GetByID(id);
            dbContext.Users.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<User> GetAll()
        {
            return dbContext.Users.ToList();
        }

        public User GetByID(string id)
        {
            return dbContext.Users.FirstOrDefault(item => item.Username == id);
        }

        public bool Update(User item)
        {
            var selected = GetByID(item.Username);
            selected.Password = item.Password;
            selected.Role = item.Role;
            return dbContext.SaveChanges() > 0;
        }
    }
}
