﻿using System.Collections.Generic;
using System.Linq;
using Model;

namespace Repository
{
    public class TraineeRepository : IRepository<Trainee>
    {
        private CandidateContext dbContext;

        public TraineeRepository()
        {
            dbContext = new CandidateContext();
        }
        public int Add(Trainee item)
        {
            dbContext.Trainees.Add(item);
            dbContext.SaveChanges();
            return item.TraineeID;
        }

        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.Trainees.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<Trainee> GetAll()
        {
            return dbContext.Trainees.ToList();
        }

        public Trainee GetByID(int id)
        {
            return dbContext.Trainees.FirstOrDefault(item => item.TraineeID == id);
        }

        public bool Update(Trainee item)
        {
            var selected = GetByID(item.TraineeID);
            selected.ClassID = item.ClassID;
            selected.Remarks = item.Remarks;
            return dbContext.SaveChanges() > 0;
        }
    }
}
