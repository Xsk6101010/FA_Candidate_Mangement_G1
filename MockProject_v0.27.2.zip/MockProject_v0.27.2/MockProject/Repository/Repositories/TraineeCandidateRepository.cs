﻿using Model;
using System.Collections.Generic;
using System.Linq;
using System;
using PagedList;
using Helper;

namespace Repository
{
    public class TraineeCandidateRepository : ITraineeCandidateRepository
    {
        private CandidateContext dbContext;

        public TraineeCandidateRepository()
        {
            dbContext = new CandidateContext();
        }

        public int Add(TraineeCandidate item)
        {
            dbContext.TraineeCandidates.Add(item);
            dbContext.SaveChanges();
            return item.TraineeCandidateID;
        }

        public bool Delete(int id)
        {
            var item = GetByID(id);
            dbContext.TraineeCandidates.Remove(item);
            return dbContext.SaveChanges() > 0;
        }

        public List<TraineeCandidate> GetAll()
        {
            return dbContext.TraineeCandidates.ToList();
        }
        public IPagedList<TraineeCandidate> GetAllPaging(int? pageNumber, int? pageSize)
        {
            var intpage = pageNumber ?? 0;
            var intpageSize = pageSize ?? 0;

            return dbContext.TraineeCandidates.OrderBy(x => x.FullName).ToPagedList(intpage, intpageSize);
        }
        public TraineeCandidate GetByID(int id)
        {
            return dbContext.TraineeCandidates.FirstOrDefault(item => item.TraineeCandidateID == id);
        }

        public bool Update(TraineeCandidate item)
        {
            var selected = GetByID(item.TraineeCandidateID);
            selected.FullName = item.FullName;
            selected.ApplicationDate = item.ApplicationDate;
            selected.DateOfBirth = item.DateOfBirth;
            selected.Gender = item.Gender;
            selected.UniversityID = item.UniversityID;
            selected.MajorID = item.MajorID;
            selected.GraduationYear = item.GraduationYear;
            selected.Phone = item.Phone;
            selected.Email = item.Email;
            selected.Type = item.Type;
            selected.ForeignLanguage = item.ForeignLanguage;
            selected.Level = item.Level;
            selected.Remarks = item.Remarks;
            selected.CVFilePath = item.CVFilePath;
            selected.Position = item.Position;
            return dbContext.SaveChanges() > 0;
        }

        public IPagedList<CandidateInfo> Search(string fullNameCandidate, DateTime? dateOfBirth, string phoneCandidate, string emailCandidate, int? pageNumber = 1, int? pageSize = 5)
        {
            int intpage = pageNumber ?? 0;
            int intpageSize = pageSize ?? 0;
            string fullName = String.IsNullOrEmpty(fullNameCandidate) ? "" : fullNameCandidate.Trim();
            string phone = String.IsNullOrEmpty(phoneCandidate) ? "" : phoneCandidate.Trim();
            string email = String.IsNullOrEmpty(emailCandidate) ? "" : emailCandidate.Trim();

            try
            {

                var model = (from c in dbContext.Candidates
                             join trc in dbContext.TraineeCandidates on c.CandidateID equals trc.TraineeCandidateID
                             join chn in dbContext.Channels on c.CandidateID equals chn.ChannelID
                             select new CandidateInfo
                             {
                                 ApplicationDate = trc.ApplicationDate,
                                 Location = trc.Location,
                                 FullName = trc.FullName,
                                 Type = trc.Type,
                                 DateOfBirth = trc.DateOfBirth,
                                 Gender = trc.Gender,
                                 Phone = trc.Phone,
                                 Email = trc.Email,
                                 UniversityID = trc.UniversityID,
                                 MajorID = trc.MajorID,
                                 Channel = chn.ChannelName,
                                 Skill = trc.Skill,
                                 GraduationYear = trc.GraduationYear,
                                 ForeignLanguage = trc.ForeignLanguage,
                                 Level = trc.Level,
                                 Status = c.Status
                             });

                if (!string.IsNullOrEmpty(fullName))
                {
                    model = model.Where(x => x.FullName.Contains(fullName.Trim()));
                }

                if (dateOfBirth != null)
                {
                    model = model.Where(x => x.DateOfBirth == dateOfBirth);
                }

                if (!string.IsNullOrEmpty(phone))
                {
                    model = model.Where(x => x.Phone.Contains(phone.Trim()));
                }

                if (!string.IsNullOrEmpty(email))
                {
                    model = model.Where(x => x.Email.Contains(email.Trim()));
                }

                return model.OrderBy(x => x.FullName).ToPagedList(intpage, intpageSize);
            }
            catch (Exception ex)
            {
                // log4net.
            }
            return null;
        }
        public List<string> GetAllDistintUniversity()
        {
            IEnumerable<TraineeCandidate> filterListByUniversity;

            filterListByUniversity = dbContext.TraineeCandidates.GroupBy(db => db.UniversityID).Select(group=>group.FirstOrDefault());
            return StringHelper.FilterEmptyString(filterListByUniversity.Select(list => list.UniversityID).ToList());
        }

        public List<string> GetAllDistintMajor()
        {
            IEnumerable<TraineeCandidate> filterListByMajor;

            filterListByMajor = dbContext.TraineeCandidates.GroupBy(db => db.MajorID).Select(group => group.FirstOrDefault());
            return StringHelper.FilterEmptyString(filterListByMajor.Select(list => list.MajorID).ToList());
        }

        //public List<string> GetAllDistintSkill()
        //{
        //    IEnumerable<TraineeCandidate> filterListBySkill;

        //    filterListBySkill = dbContext.TraineeCandidates.GroupBy(db => db.Skill).Select(group => group.FirstOrDefault());
        //    return filterListBySkill.Select(list => list.Skill).ToList();
        //}
    }
}


