﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Model;

namespace MockProject
{
    public class DBSetup
    {
        public static void Initilize()
        {

        }
    }
}