using System;

using Unity;
using Model;
using Repository;
using Service;

namespace MockProject
{
    /// <summary>
    /// Specifies the Unity configuration for the main container.
    /// </summary>
    public static class UnityConfig
    {
        #region Unity Container
        private static Lazy<IUnityContainer> container =
          new Lazy<IUnityContainer>(() =>
          {
              var container = new UnityContainer();
              RegisterTypes(container);
              return container;
          });

        /// <summary>
        /// Configured Unity Container.
        /// </summary>
        public static IUnityContainer Container => container.Value;
        #endregion

        /// <summary>
        /// Registers the type mappings with the Unity container.
        /// </summary>
        /// <param name="container">The unity container to configure.</param>
        /// <remarks>
        /// There is no need to register concrete types such as controllers or
        /// API controllers (unless you want to change the defaults), as Unity
        /// allows resolving a concrete type even if it was not previously
        /// registered.
        /// </remarks>
        public static void RegisterTypes(IUnityContainer container)
        {
            // NOTE: To load from web.config uncomment the line below.
            // Make sure to add a Unity.Configuration to the using statements.
            // container.LoadConfiguration();

            // TODO: Register your type's mappings here.
            // container.RegisterType<IProductRepository, ProductRepository>();

            container.RegisterType<IRepository<Channel>, ChannelRepository>();
            container.RegisterType<IRepository<ClassBatch>, ClassBatchRepository>();
            container.RegisterType<IRepository<Trainee>, TraineeRepository>();
            container.RegisterType<ITraineeCandidateRepository,TraineeCandidateRepository>();
            container.RegisterType<ICandidateRepository, CandidateRepository>();
            container.RegisterType<IUserRepository, UserRepository>();
            container.RegisterType<IInterviewRepository, InterviewRepository>();
            container.RegisterType<IEntryTestRepository, EntryTestRepository>();
            container.RegisterType<IOfferRepository, OfferRepository>();
            container.RegisterType<IHistoryRepository, HistoryRepository>();

            container.RegisterType<ICandidateService, CandidateService>();
            container.RegisterType<IService<Channel>, ChannelService>();
            container.RegisterType<IService<ClassBatch>, ClassBatchService>();
            container.RegisterType<IService<Trainee>, TraineeService>();
            container.RegisterType<ITraineeCandidateService, TraineeCandidateService>();
            container.RegisterType<IUserService, UserService>();
            container.RegisterType<IInterviewService, InterviewService>();
            container.RegisterType<IEntryTestService, EntryTestService>();
            container.RegisterType<IOfferService, OfferService>();
            container.RegisterType<IHistoryService, HistoryService>();
        }
    }
}