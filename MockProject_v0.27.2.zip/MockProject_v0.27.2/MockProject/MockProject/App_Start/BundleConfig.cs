﻿using System.Web;
using System.Web.Optimization;

namespace MockProject
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/Content/mycss").Include(
                      "~/Content/css/jquery.toast.css",
                      "~/Content/css/bootstrap.css",
                      "~/Content/css/style.css",
                      "~/Content/css/font-awesome.css",
                      "~/Content/css/SidebarNav.min.css",
                      "~/Content/css/custom.css",
                      "~/Content/css/css/owl.carousel.css",
                      "~/Content/css/mycss.css",
                      "~/Content/css/PagedList.css",
                      "~/Content/css/css/owl.carousel.css"));
            bundles.Add(new ScriptBundle("~/bundles/myjs").Include(
                      "~/Content/js/jquery.toast.js",
                      "~/Content/js/jquery-1.11.1.min.js",
                      "~/Content/js/Chart.js",
                      "~/Content/js/metisMenu.min.js",
                      "~/Content/js/custom.js",
                      "~/Content/js/pie-chart.js",
                      "~/Content/js/owl.carousel.js",
                      "~/Content/js/owl.carousel.js",
                      "~/Content/js/jquery.unobtrusive-ajax.js",
                      "~/Content/js/myjs.js"));
            bundles.Add(new ScriptBundle("~/bundles/myjsbotton").Include(
                     "~/Content/js/Chart.bundle.js",
                     "~/Content/js/utils.js",
                     "~/Content/js/classie.js",
                     "~/Content/js/myjsbotton1.js",
                     "~/Content/js/jquery.nicescroll.js",
                     "~/Content/js/scripts.js",
                     "~/Content/js/SimpleChart.js",
                     "~/Content/js/myjsbotton3.js",
                     "~/Content/js/bootstrap.js"));
        }
    }
}
