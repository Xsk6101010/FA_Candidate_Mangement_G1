﻿
var interviews = [];
var count;
count = $("[name='time']").val();

$(".csstable").css("height", "260px");
$(".csstable").css("overflow-y", "auto");

$("[name='btnUpdateDB']").css("display", "none");
$("[name='btnUpdateStore']").css("display", "none");
$("[name='btnReset']").css("display", "none");
$("[name='btnSave']").css("display", "none");
$("#errResultNull").css("display", "none");
$("#errDateNull").css("display", "none");
$("#errDate").css("display", "none");
$(document).ready(function () {
    showSave();
})
function showSave() {
    if (interviews.length != 0) {
        $("[name='btnSave']").fadeIn();
    }
    else {
        $("[name='btnSave']").fadeOut();
    }
}
function buttonFade() {
    var length = $("#check:checked").length;
    var radio = $("#radio:checked").length;
    if (length == 1) {
        $("[name='btnUpdateDB']").fadeIn();
        $("[name='btnReset']").fadeIn();
        $("[name='btnAdd']").fadeOut();
        $("[name='btnUpdateStore']").fadeOut();
    }
    if (radio == 1) {
        $("[name='btnUpdateDB']").fadeOut();
        $("[name='btnReset']").fadeIn();
        $("[name='btnAdd']").fadeOut();
        $("[name='btnUpdateStore']").fadeIn();
    }
}
$("[name='date']").click(function () {
    $("[name='date']").css('border', '1px solid rgba(0, 0, 0, 0.2)');
    $("#errDate").fadeOut();
    $("#errDateNull").fadeOut();
});
$("[name='time']").keydown(function () {
    $("[name='time']").css('border', '1px solid rgba(0, 0, 0, 0.2)');

});
$("[name='result']").click(function () {
    $("[name='result']").css('border', '1px solid rgba(0, 0, 0, 0.2)');
    $("#errResultNull").fadeOut();

});
var id;
function checkFunction() {
    buttonFade();
    var checked = $("[name='check']:checked").val();
    id = checked;
    var time = $("#time_" + id).val();
    var date = (new Date($("#date_" + id).val()));
    date.setDate(date.getDate() + 1);
    var interview = $("#interview_" + id).val();
    var comment = $("#comment_" + id).val();
    var result = $("#result_" + id).val();

    $("[name='time']").val(time);
    $("[name='date']").val((new Date(date)).toISOString().split("T")[0]);
    $("[name='interview']").val(interview);
    $("[name='commnet']").val(comment);
    $("[name='result']").val(result);
    showSave();
}
function radioFunction() {
    buttonFade();
    var checked = $("#radio:checked").val();
    var date = (new Date($("#radiodate_" + checked).val()));
    var interview = $("#radiointerview_" + checked).val();
    var comment = $("#radiocomment_" + checked).val();
    var result = $("#radioresult_" + checked).val();

    $("[name='time']").val(checked);
    $("[name='date']").val((new Date(date)).toISOString().split("T")[0]);
    $("[name='interview']").val(interview);
    $("[name='commnet']").val(comment);
    $("[name='result']").val(result);
    showSave();
}
function addFuntion() {
    var time = parseInt($("[name='time']").val());
    if (typeof (Storage) !== "undefined") {
        if (!validate()) {
            return false;
        }
        var interview = {
            CandidateID: $("[name='candidateID']").val(),
            Time: time,
            Date: $("[name='date']").val(),
            Interviewer: $("[name='interview']").val(),
            Comments: $("[name='commnet']").val(),
            Result: $("[name='result']").val()
        }
        if (interviews == null) {
            interviews = [];
            interviews.push(interview);

        } else {
            interviews.push(interview);

        }
        time = time + 1;
        count = time;
        $("[name='time']").val(time);
        $('#interviewList tr:last').after('<tr id="tr_' + interview.Time + '"><td> <input type="radio" name="check" id="radio" value="' + interview.Time + '" onclick="radioFunction()">'
            + '<input type="hidden" name="radioInterviewer" id="radiointerview_' + interview.Time + '" value="' + interview.Interviewer + '">'
            + '<input type="hidden" name="radioComments" id="radiocomment_' + interview.Time + '" value="' + interview.Comments + '">'
            + '<input type="hidden" name="radioResult" id="radioresult_' + interview.Time + '" value="' + interview.Result + '"></td > <td>'
            + '<input type="hidden" name="radioDate" id="radiodate_' + interview.Time + '" value="' + interview.Date + '" >'
            + interview.Time + '</td> <td>' + interview.Date + '</td> <td>' + interview.Interviewer + '</td> <td>' + interview.Comments + '</td> <td>' + interview.Result + '</td></tr > ');
    }
    resetFuntion();
    showSave();
}

function updateDBFuntion() {
    var idcandidate = $("[name='candidateID']").val();
    var interview = {
        InterviewID: id,
        CandidateID: $("[name='candidateID']").val(),
        Time: $("[name='time']").val(),
        Date: $("[name='date']").val(),
        Interviewer: $("[name='interview']").val(),
        Comments: $("[name='commnet']").val(),
        Result: $("[name='result']").val()
    }
    $.ajax({
        url: "/Candidate/UpdateInterview",
        data: JSON.stringify(interview),
        method: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (resultMessage) {
            if (resultMessage.Success == true) {
                window.location.href = "/Candidate/Update/" + idcandidate + "#interview";
                $.toast({
                    heading: 'Success',
                    text: resultMessage.Message,
                    showHideTransition: 'slide',
                    icon: 'success'
                })
            }
            else {
                $.toast({
                    heading: 'Error',
                    text: resultMessage.Message,
                    showHideTransition: 'fade',
                    icon: 'error'
                })
            }
        },
        error: function (errorMessage) {
            if (errorMessage.Success == false) {
                $.toast({
                    heading: 'Error',
                    text: resultMessage.Message,
                    showHideTransition: 'fade',
                    icon: 'error'
                })
            }
        }
    });
    resetFuntion();
    showSave();
}
function updateStoreFuntion() {
    var checked = $("#radio:checked").val();
    var interview = {
        CandidateID: $("[name='candidateID']").val(),
        Time: $("[name='time']").val(),
        Date: $("[name='date']").val(),
        Interviewer: $("[name='interview']").val(),
        Comments: $("[name='commnet']").val(),
        Result: $("[name='result']").val()
    }
    var sum = 0;
    $.each(interviews, function (i, item) {
        if (checked == item.Time) {
            interviews.splice(sum, 1, interview);
            return false;
        }
        sum++;
    })
    $("tr[id^='tr_']").remove();
    $.each(interviews, function (i, item) {
        $('#interviewList tr:last').after('<tr id="tr_' + item.Time + '"><td> <input type="radio" name="check" id="radio" value="' + item.Time + '" onclick="radioFunction()">'
            + '<input type="hidden" name="radioInterviewer" id="radiointerview_' + item.Time + '" value="' + item.Interviewer + '">'
            + '<input type="hidden" name="radioComments" id="radiocomment_' + item.Time + '" value="' + item.Comments + '">'
            + '<input type="hidden" name="radioResult" id="radioresult_' + item.Time + '" value="' + item.Result + '"></td><td>'
            + '<input type="hidden" name="radioDate" id="radiodate_' + item.Time + '" value="' + item.Date + '" >'
            + item.Time + '</td><td>' + item.Date + '</td> <td>' + item.Interviewer + '</td> <td>' + item.Comments + '</td> <td>' + item.Result + '</td></tr > ');
    })
    resetFuntion();
    showSave();
}
var err = $("[name='message28']").val();
function saveFunction() {
    //var obj = { 'Interviews': interviews };
    if (interviews.length != 0) {
        var idcandidate = $("[name='candidateID']").val();
        $.ajax({
            url: "/Candidate/CreateInterview",
            data: JSON.stringify(interviews),
            method: "POST",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            success: function (resultMessage) {
                if (resultMessage.Success == true) {
                    interviews = [];
                    $.toast({
                        heading: 'Success',
                        text: resultMessage.Message,
                        showHideTransition: 'slide',
                        icon: 'success'
                    })
                    window.location.href = "/Candidate/Update/" + idcandidate + "#interview";
                    showSave();

                    location.reload(true);
                }
                else {
                    $.toast({
                        heading: 'Error',
                        text: resultMessage.Message,
                        showHideTransition: 'fade',
                        icon: 'error'
                    })
                }
            },
            error: function (errorMessage) {
                if (errorMessage.Success == false) {
                    $.toast({
                        heading: 'Error',
                        text: errorMessage.Message,
                        showHideTransition: 'fade',
                        icon: 'error'
                    })
                }
            }
        });

        
    }
    else {
        $.toast({
            heading: 'Error',
            text: err,
            showHideTransition: 'fade',
            icon: 'error'
        })
        return false;
    }
}
function resetFuntion() {
    $("[name='time']").val(count);
    $("[name='date']").val("");
    $("[name='interview']").val("");
    $("[name='commnet']").val("");
    $("[name='result']").val("");
    $("[name='check']").attr("checked", false)

    $("[name='btnUpdateDB']").fadeOut();
    $("[name='btnReset']").fadeOut();
    $("[name='btnAdd']").fadeIn();
    $("[name='btnUpdateStore']").fadeOut();
}

function validate() {
    var check = true;
    if ($("[name='date']").val() === "") {
        $("[name='date']").css('border', '1px solid red');
        $("#errDateNull").fadeIn();
        $("#errDateNull").css("color", "red");
        check = false;
    }
    else {
        if (isFutureDate($("[name='date']").val()) == true) {
            $("[name='date']").css('border', '1px solid red');
            $("#errDate").fadeIn();
            $("#errDate").css("color", "red");
            check = false;
        }
    }
    if ($("[name='time']").val() === "") {
        $("[name='time']").css('border', '1px solid red');
        check = false;
    }
    if ($("[name='result']").val() === null) {
        $("[name='result']").css('border', '1px solid red');
        $("#errResultNull").fadeIn();
        $("#errResultNull").css("color", "red");
        check = false;
    }
    return check;
}
function isFutureDate(idate) {
    var today = new Date();
    var target = new Date(idate);
    if (target < today)
        return false;
    else
        return true;
}
