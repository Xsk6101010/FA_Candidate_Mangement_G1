﻿//Add Data Function
$(document).ready(function () {
    $("#cancelBtn").click(function () {
        window.location.href = '/Candidate/ListCandidate/';
    });
    $("#location-selector").change(function () {
        if ($(this).val() === "Other") {
            $("[name = 'TraineeCandidate.Location']").css("display", "block")
            $("[name = 'TraineeCandidate.Location']").val("");
        }
        else {
            $("[name = 'TraineeCandidate.Location']").css("display", "none");
            $("[name = 'TraineeCandidate.Location']").val($(this).val());
        }
    });

    $("#university-selector").change(function () {
        if ($(this).val() === "Other") {
            $("[name = 'TraineeCandidate.UniversityID']").css("display", "block");
            $("[name = 'TraineeCandidate.UniversityID']").val("");
        }
        else {
            $("[name = 'TraineeCandidate.UniversityID']").css("display", "none");
            $("[name = 'TraineeCandidate.UniversityID']").val($(this).val());
        }
    });

    $("#major-selector").change(function () {
        if ($(this).val() === "Other") {
            $("[name = 'TraineeCandidate.MajorID']").css("display", "block")
            $("[name = 'TraineeCandidate.MajorID']").val("");
        }
        else {
            $("[name = 'TraineeCandidate.MajorID']").css("display", "none");
            $("[name = 'TraineeCandidate.MajorID']").val($(this).val());
        }
    });

    $("#skill-selector").change(function () {
        if ($(this).val() === "Other") {
            $("[name = 'TraineeCandidate.Skill']").css("display", "block")
            $("[name = 'TraineeCandidate.Skill']").val("");
        }
        else {
            $("[name = 'TraineeCandidate.Skill']").css("display", "none");
            $("[name = 'TraineeCandidate.Skill']").val($(this).val());
        }
    });

    $("#foreign-language-selector").change(function () {
        if ($(this).val() === "Other") {
            $("[name = 'TraineeCandidate.ForeignLanguage']").css("display", "block")
            $("[name = 'TraineeCandidate.ForeignLanguage']").val("");
        }
        else {
            $("[name = 'TraineeCandidate.ForeignLanguage']").css("display", "none");
            $("[name = 'TraineeCandidate.ForeignLanguage']").val($(this).val());
        }
    });

    $("#foreign-language-level-selector").change(function () {
        if ($(this).val() === "Other") {
            $("[name = 'TraineeCandidate.Level']").css("display", "block")
            $("[name = 'TraineeCandidate.Level']").val("");
        }
        else {
            $("[name = 'TraineeCandidate.Level']").css("display", "none");
            $("[name = 'TraineeCandidate.Level']").val($(this).val());
        }
    });
});