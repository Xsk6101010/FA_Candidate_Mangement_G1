﻿
$(document).ready(function () {
    buttonFade();
    $("#errorTransfer").css("display", "none");
    $("#errorPosition").css("display", "none");
    $("[name='Position']").click(function () {
        $("[name='Position']").css('border', '1px solid rgba(0, 0, 0, 0.2)');
        $("#errorPosition").fadeOut();
    })
    $("[name='TransferTo']").click(function () {
        $("[name='TransferTo']").css('border', '1px solid rgba(0, 0, 0, 0.2)');
        $("#errorTransfer").fadeOut();
    })

    function validate() {
        var check = true;
        if ($("[name='Position']").val() === "") {
            $("[name='Position']").css('border', '1px solid red');
            $("#errorPosition").fadeIn();
            $("#errorPosition").css("color", "red");
            check = false;
        }
        if ($("[name='TransferTo']").val() === null) {
            $("[name='TransferTo']").css('border', '1px solid red');
            $("#errorTransfer").fadeIn();
            $("#errorTransfer").css("color", "red");
            check = false;
        }
        return check;
    }

    function buttonFade() {

        var length = $("[name='check']:checkbox:checked").length;
        $("#transfer-div").fadeOut();
        if (length < 1) {
            $("#view-div").fadeOut();
            $("#update-div").fadeOut();
            $("#delete-div").fadeOut();
            //$("#transfer-div").fadeOut();
        }
        if (length === 1) {
            $("#view-div").fadeIn();
            $("#update-div").fadeIn();
        }
        if (length > 0) {
            $("#delete-div").fadeIn();
            //$("#transfer-div").fadeIn();
            if (length > 1) {
                $("#view-div").fadeOut();
                $("#update-div").fadeOut();
            }
        }
    }
    $("[name='check']").change(function () {
        buttonFade();
        var checked = $("[name='check']:checked").val();
        var type = $("#type_" + checked).val();
        var isNonCandidate = true;
        var checks = [];
        var length = $("[name='check']:checkbox:checked").length;
        for (var item = 0; item < length; item++) {
            var id = parseInt($("[name='check']:checked")[item].value);
            var type = $("#type_" + id).val();
            checks.push(type);
        }
        $.each(checks, function (i, item) {
            if (item != "Candidate") {
                isNonCandidate = false;
            }
        })
        if (isNonCandidate) {
            $("#transfer-div").fadeIn();
        }
        else {
            $("#transfer-div").fadeOut();
        }
    });

    $("#update-btn").click(function () {
        var length = $("[name='check']:checkbox:checked").length;
        if (length === 1) {
            var idCandidate = parseInt($("[name='check']:checked").val());
            window.location.href = "/Candidate/Update/" + idCandidate;
        }
        else {
            alert("Only one checkbox is selected to perform the update!!");
        }
    });
    $("#view-btn").click(function () {
        var length = $("[name='check']:checkbox:checked").length;
        if (length === 1) {
            var idCandidate = parseInt($("[name='check']:checked").val());
            window.location.href = "/Candidate/View/" + idCandidate;
        }
        else {
            alert("Only one checkbox is selected to perform the view!!");
        }
    });
    $("#delete-btn").click(function () {
        var length = $("[name='check']:checkbox:checked").length;
        $("#delete-modal-body").text("Delete " + length + (length == 1 ? " record?" : " records?"));
    });

    $("#confirm-delete-btn").click(function () {
        var candidates = [];
        var length = $("[name='check']:checkbox:checked").length;
        for (var item = 0; item < length; item++) {
            var id = parseInt($("[name='check']:checked")[item].value);
            candidates.push(id);
        }
        $.ajax({
            url: "/Candidate/Delete",
            data: JSON.stringify(candidates),
            method: "POST",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            success: function (resultMessage) {
                if (resultMessage.Success == true) {
                    window.location.href = "/Candidate/ListCandidate";
                }
            }

        }).done(function () {
            $.toast({
                heading: 'Success',
                text: resultMessage.Message,
                showHideTransition: 'slide',
                icon: 'success'
            });
        });
    });

    $("#transfer-btn").click(function () {
        var transfers = [];
        var length = $("[name='check']:checkbox:checked").length;
        var candidates;
        if (length === 0) {
            alert("Request to select at least one checkbox to delete!!");
        }
        else {
            if (!validate()) {
                return false;
            }
            if (transfers === null) {
                transfers = [];
            }
            var transferTo = $("[name='TransferTo']").val();
            var position = $("[name='Position']").val();
            for (var item = 0; item < length; item++) {
                if (typeof (Storage) !== "undefined") {
                    var id = $("[name='check']:checked")[item].value;
                    var application = $("#applicationDate_" + id).val();
                    var location = $("#location_" + id).val();
                    var fullname = $("#fullname_" + id).val();
                    var dateOfBirth = $("#dateOfBirth_" + id).val();
                    var gender = $("#gender_" + id).val();
                    var universityID = $("#universityID_" + id).val();
                    var majorID = $("#majorID_" + id).val();
                    var graduationYear = $("#graduationYear_" + id).val();
                    var phone = $("#phone_" + id).val();
                    var email = $("#email_" + id).val();
                    var skill = $("#skill_" + id).val();
                    var foreignLanguage = $("#foreignLanguage_" + id).val();
                    var level = $("#level_" + id).val();
                    var remarks = $("#remarks_" + id).val();
                    var cvFilePath = $("#cvFilePath_" + id).val();

                    var transfer = {
                        TraineeCandidateID: id,
                        ApplicationDate: application,
                        Location: location,
                        FullName: fullname,
                        DateOfBirth: dateOfBirth,
                        Gender: gender,
                        UniversityID: universityID,
                        MajorID: majorID,
                        GraduationYear: graduationYear,
                        Phone: phone,
                        Email: email,
                        Type: transferTo,
                        Skill: skill,
                        ForeignLanguage: foreignLanguage,
                        Level: level,
                        Remarks: remarks,
                        CVFilePath: cvFilePath,
                        Position: position
                    }
                    transfers.push(transfer);
                }
            }
            $.ajax({
                url: "/Candidate/TransferAdd/",
                data: JSON.stringify(transfers),
                method: "POST",
                contentType: "application/json;charset=utf-8",
                dataType: "json",
                success: function (resultMessage) {
                    if (resultMessage.Success == true) {
                        $.toast({
                            heading: 'Warning',
                            text: 'It is going to be supper easy for you to use ;)',
                            showHideTransition: 'plain',
                            icon: 'warning'
                        })
                        window.location.href = "/Candidate/ListCandidate/";
                    }
                    else {
                        $.toast({
                            heading: 'Error',
                            text: resultMessage.Message,
                            showHideTransition: 'fade',
                            icon: 'error'
                        })
                    }
                },
                error: function (errorMessage) {
                    if (errorMessage.Success == false) {
                        $.toast({
                            heading: 'Error',
                            text: errorMessage.Message,
                            showHideTransition: 'fade',
                            icon: 'error'
                        })
                    }
                }
            });
        }
    });
});