﻿
function cancelFunction() {
    var page = $("[name='page']").val();
    window.location.href = '/?pageNumber=' + page;
}