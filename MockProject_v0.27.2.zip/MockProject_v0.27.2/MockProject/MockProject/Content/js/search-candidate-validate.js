﻿$(document).ready(function () {
    $("#CancelSearchBtn").click(function () {
        window.location.href = '/Candidate/ListCandidate/';
    });
   
    $("#SearchBtn").click(function () {
        var IsChecked = true;

        if ($("#FullName").val().trim() != '' && !validateFullNameLength($("#FullName").val().trim())) {
            IsChecked = false;
        }

        if ($("[name='DateOfBirth']").val() != '' && !validateDate($("#DateOfBirth").val().trim())) {
            IsChecked = false;
        }

        if ($("[name='Phone']").val().trim() != '' && !validatePhoneNumber($("#Phone").val().trim())) {
            IsChecked = false;
        }
        if ($("[name='Email']").val().trim() != '' && !validateEmail($("#Email").val().trim())) {
            IsChecked = false;
        }
        return IsChecked;
    });


    function validateFullNameLength(fullName) {

        if (fullName.length > 30) {
            $("[name = 'Search.FullName.msg17']").show();
            return false;
        }
        else {
            $("[name = 'Search.FullName.msg17']").hide();
            return true;
        }

    };

    function validatePhoneNumber(phone) {

        if (isFormatPhoneWithZeroBegin(phone)) {
            $("[name = 'Search.Phone.msg18']").hide();
            if (isFormatPhoneMaxLength(phone)==true) {
                $("[name = 'Search.Phone.msg19']").hide();
                return true;
            }
            else
            {
                $("[name = 'Search.Phone.msg19']").show();
                return false;
            }
        }
        else
        {
            $("[name = 'Search.Phone.msg18']").show();
        }
    }
    function getToday() {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }
        today = yyyy + '-' + mm + '-' + dd;
        return today;
    }
    function validateDate(date) {
        if (isFormatDate(date)) {
            if (date >= getToday()) {
                $("[name = 'Search.DateOfBirth.msg20']").show();
                return false;
            }
            else {
                $("[name = 'Search.DateOfBirth.msg20']").hide();
                return true;
            }
        }
    }

    function isFormatDate(date) {
        if (date === '') {
            $("[name = 'Search.DateOfBirth.msg10']").show();
            return false;
        }
        $("[name = 'Search.DateOfBirth.msg10']").hide();
        return true;
    }

    function isFormatPhoneWithZeroBegin(number) {
        var pattern = new RegExp(/^([+-]?[0-9]\d*|0)$/);
        if (pattern.test(number) && (String(number).charAt(0) === '0')) {
            return true;
        }
        return false;
    }

    function isFormatPhoneMaxLength(number) {
        if (isFormatPhoneWithZeroBegin(number) && (number.length <= 14)) {
            return true;
        }
        return false;
    }

    function validateEmail(email) {

        var emailReg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (emailReg.test(email)) {
            $("[name = 'Search.Email.msg21']").hide();
            return true;
        }
        else {
            $("[name = 'Search.Email.msg21']").show();
            return false;
           }
    }
});
