﻿candidates = [];

function convertDate(date) {
    return new Date(parseInt((date).match(/\d+/)[0]));

}

function ToDateString(d) {
    return ((d.getDate()) + "").padStart(2, "0")
          + "/" + (d.getMonth() + 1 + "").padStart(2, "0")
          + "/" + d.getFullYear();
}

var input = document.getElementById('excel-file');
input.addEventListener('change', function () {
    if (document.getElementById("excel-file").files.length > 0) {
        var formData = new FormData();
        var totalFiles = document.getElementById("excel-file").files.length;
        for (var i = 0; i < totalFiles; i++) {
            var file = document.getElementById("excel-file").files[i];
            formData.append("FileUpload", file);
        }
        $.ajax({
            method: "POST",
            url: '/Import/GetImportedList',
            data: formData,
            dataType: 'json',
            contentType: false,
            processData: false,
            success: function (result) {
                $.each(result, function (id, item) {
                    item.TraineeCandidate.ApplicationDate = convertDate(item.TraineeCandidate.ApplicationDate);
                    item.TraineeCandidate.DateOfBirth = convertDate(item.TraineeCandidate.DateOfBirth);
                    candidates.push(item);
                    $("#imported-candidate").fadeIn(function () {
                        $(this).append(
                        "<tr id='tr_" + (id+1)+"'>" +
                        "<td>" + (id + 1) + "</td>" +
                        "<tdid ='td_id_" + item.CandidateID + "'>" + item.CandidateID + "</td>" +
                        "<td>" + ToDateString(item.TraineeCandidate.ApplicationDate) + "</td>" +
                        "<td>" + item.TraineeCandidate.Location + "</td>" +
                        "<td>" + item.TraineeCandidate.FullName + "</td>" +
                        "<td>" + item.TraineeCandidate.Type + "</td>" +
                        "<td>" + ToDateString(item.TraineeCandidate.DateOfBirth) + "</td>" +
                        "<td>" + item.TraineeCandidate.Gender + "</td>" +
                        "<td id='td_phone_" + (id + 1) + "'>" + item.TraineeCandidate.Phone + "</td>" +
                        "<td id='td_email_" + (id + 1) + "'>" + item.TraineeCandidate.Email + "</td>" +
                        "<td>" + item.TraineeCandidate.UniversityID + "</td>" +
                        "<td>" + item.TraineeCandidate.MajorID + "</td>" +
                        "<td>" + item.ChannelID + "</td>" +
                        "<td>" + item.TraineeCandidate.Skill + "</td>" +
                        "<td>" + item.TraineeCandidate.GraduationYear + "</td>" +
                        "<td>" + item.TraineeCandidate.ForeignLanguage + "</td>" +
                        "<td>" + item.TraineeCandidate.Level + "</td>" +
                        "<td>" + item.Status + "</td>" +
                        + "</tr>")
                    })
                });
            },
            error: function (error) {
                alert("Failed to import");
            }
        });
    }
}, false);

$("#cancel-btn").click(function () {
    document.getElementById("excel-file").value = "";
    candidates = [];
    $("tbody").fadeOut(function () {
        $(this).html('');
    });
});
$("#back-btn").click(function () {
    window.location.href = '/Candidate/ListCandidate/';
});

$("#import-btn").click(function () {
    if (candidates == null || candidates.length < 1) {
        $.toast({
            heading: 'Failed to import',
            text: "Please choose file to import",
            showHideTransition: 'slide',
            icon: 'error'
        })
        return false;
    }
    $.ajax({
        method: "POST",
        url: '/Import/ImportCandidateList',
        data: JSON.stringify(candidates),
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        success: function (response) {
            $.each(response.Results, function (index, item) {
                if (item.error == true) {
                    $("#tr_" + item.row + " td").css("background-color", "#f79b9b");
                }
                else {
                    $("#tr_" + item.row + " td").css("background-color", "#afe4af");
                }
            });
            if (response.Imported > 0)
            $.toast({
                heading: 'Success import',
                text: response.Imported + " records successfully added to database",
                showHideTransition: 'slide',
                icon: 'success'
            })
            if(response.Existed > 0)
            $.toast({
                heading: 'Failed to import',
                text: response.Existed + " records has phone or email existed in database",
                showHideTransition: 'slide',
                icon: 'error'
            })
        }
    });
});

//if (item.checkResult.isEmailExisted == true) {

//}
//if (item.checkResult.isPhoneExisted == true) {
//    $("#tr_" + item.row + " td").css("background-color", "#f79b9b");
//}