﻿var countTimes;
var entrytests = [];
var id
countTimes = $("[name='Times']").val();

$("[name='btnUpdateToDB']").css("display", "none")
$("[name='btnUpdateToTable']").css("display", "none");
$("[name='btnToReset']").css("display", "none");

showEntryTestSaveBtn();
function appearButtonControl() {
    var length = $("#checkEntrytestID:checked").length;
    var radio = $("#radioEntrytestID:checked").length;
    if (length == 1) {
        $("[name='btnUpdateToDB']").fadeIn();
        $("[name='btnToReset']").fadeIn();
        $("[name='btnToAdd']").fadeOut();
        $("[name='btnUpdateToTable']").fadeOut();
        $("[name='save']").fadeOut();
    }
    if (radio == 1) {
        $("[name='btnUpdateToDB']").fadeOut();
        $("[name='btnToReset']").fadeIn();
        $("[name='btnToAdd']").fadeOut();
        $("[name='btnUpdateToTable']").fadeIn();
        $("[name='save']").fadeOut();
    }
}
$("#EntryTestCancelBtn").onclick(function () {
    location.reload(true);
});




function showEntryTestSaveBtn() {
    if (entrytests.length > 0) {
        $("[name='EntryTestSaveBtn']").fadeIn();
    }
    else {
        $("[name='EntryTestSaveBtn']").fadeOut();
    }
}

function checkEntryTest() {
    appearButtonControl();
    $("[name='EntryTestSaveBtn']").fadeOut();
    var checked = $("[name='checkEntrytestID']:checked").val();
    id = checked;
    var time = $("#timeEntrytestID_" + id).val();
    var date = (new Date($("#dateEntryTestID_" + id).val()));
    date.setDate(date.getDate() + 1);
    var languagevaluator = $("#languagevaluatorEntryTestID_" + id).val();
    var languageresult = $("#languageresultEntryTestID_" + id).val();
    var technicalvaluator = $("#technicalvaluatorEntryTestID_" + id).val();
    var technicalresult = $("#technicalresultEntryTestID_" + id).val();
    var result = $("#resultEntryTestID_" + id).val();


    $("[name='Times']").val(time);
    $("[name='Date']").val((new Date(date)).toISOString().split("T")[0]);
    $("[name='LanguageValuator']").val(languagevaluator);
    $("[name='LanguageResult']").val(languageresult);
    $("[name='TechnicalValuator']").val(technicalvaluator);
    $("[name='TechnicalResult']").val(technicalresult);
    $("[name='Result']").val(result);
}

function radioEntryTestID() {
    appearButtonControl();
    $("[name='EntryTestSaveBtn']").fadeOut();
    var checked = $("#radioEntrytestID:checked").val();
    var id = checked;
    var time = $("#radioEntrytestID:checked").val();
    var date = ($("#radioDate_" + id).val());

    var languagevaluator = $("#radioLanguageValuator_" + id).val();
    var languageresult = $("#radioLanguageResult_" + id).val();
    var technicalvaluator = $("#radioTechnicalValuator_" + id).val();
    var technicalresult = $("#radioTechnicalResult_" + id).val();
    var result = $("#radioResult_" + id).val();

    $("[name='Times']").val(time);
    $("[name='Date']").val(convertDate(date));
    $("[name='LanguageValuator']").val(languagevaluator);
    $("[name='LanguageResult']").val(languageresult);
    $("[name='TechnicalValuator']").val(technicalvaluator);
    $("[name='TechnicalResult']").val(technicalresult);
    $("[name='Result']").val(result);

}



function convertDate(dateString) {
    var p = dateString.split(/\D/g)
    return [p[2], p[1], p[0]].join("-")
}

function validateFields() {
    if (validateEntryTestMandatory() && validateEntryTestFutureDate() &&
          validateInteger($("[name='TechnicalResult']").val()) &&
          validateInteger($("[name='LanguageResult']").val())) {

        return true;
    }
    return false;

}
function addEntryTest() {
    if (!validateFields()) {
        return false;
    }
    var times = parseInt($("[name='Times']").val());
    var entrytest = {
        CandidateID: $("[name='CandidateID']").val(),
        Time: $("[name='Times']").val(),
        Date: $("[name='Date']").val(),
        LanguageValuator: $("[name='LanguageValuator']").val(),
        LanguageResult: $("[name='LanguageResult']").val(),
        TechnicalValuator: $("[name='TechnicalValuator']").val(),
        TechnicalResult: $("[name='TechnicalResult']").val(),
        Result: $("[name='Result']").val()
    }
    if (entrytests == null) {
        entrytests = [];
        entrytests.push(entrytest);
    } else {
        entrytests.push(entrytest);
    }
    times = times + 1;
    countTimes = times
    $("[name='Times']").val(times);
    $('#entrytestTable tr:last').after('<tr id="tr_' + entrytest.Time + '"><td><input type="radio" name="checkEntrytestID" id="radioEntrytestID" value="' + entrytest.Time + '" onclick=radioEntryTestID(); />'
              + '<input type="hidden" name="radioDate" id="radioDate_' + entrytest.Time + '" value="' + convertDate(entrytest.Date) + '">'
              + '<input type="hidden" name="radioLanguageValuator" id="radioLanguageValuator_' + entrytest.Time + '" value="' + entrytest.LanguageValuator + '">'
              + '<input type="hidden" name="radioLanguageResult" id="radioLanguageResult_' + entrytest.Time + '" value="' + entrytest.LanguageResult + '"></td > <td>'
              + '<input type="hidden" name="radioTechincalValuator" id="radioTechnicalValuator_' + entrytest.Time + '" value="' + entrytest.TechnicalValuator + '" >'
              + '<input type="hidden" name="radioTechnicalResult" id="radioTechnicalResult_' + entrytest.Time + '" value="' + entrytest.TechnicalResult + '">'
              + '<input type="hidden" name="radioResult" id="radioResult_' + entrytest.Time + '" value="' + entrytest.Result + '">'

              + entrytest.Time + '</td><td>' + convertDate(entrytest.Date) + '</td><td>' + entrytest.LanguageValuator + '</td><td>' + entrytest.LanguageResult + '</td><td>' + entrytest.TechnicalValuator + '</td><td>'
              + entrytest.TechnicalResult + '</td><td>' + entrytest.Result + '</td></tr>');
    showEntryTestSaveBtn();
    resetData();

}


function saveEntryTestFunction() {
   // var obj = { 'Entrytests': entrytests };
    var candidateID = $("[name='CandidateID']").val();
    $.ajax({
        url: "/Candidate/CreateEntryTest",
        data: JSON.stringify(entrytests),
        method: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (resultMessage) {
            if (resultMessage.Success == true) {
                entrytests = [];
                $.toast({
                    heading: 'Success',
                    text: resultMessage.Message,
                    showHideTransition: 'slide',
                    icon: 'success'
                })
                window.location.href = "/Candidate/Update/" + candidateID + "#entryTest";
                location.reload(true);
            }
            else
            {
                $.toast({
                    heading: 'Error',
                    text: resultMessage.Message,
                    showHideTransition: 'fade',
                    icon: 'error'
                })
            }
        },
        error: function (errorMessage) {
            if (errorMessage.Success == false) {
                $.toast({
                    heading: 'Error',
                    text: errorMessage.Message,
                    showHideTransition: 'fade',
                    icon: 'error'
                })
            }
        }
    });
}

function updateToDB() {
    var candidateID = $("[name='CandidateID']").val();
    var id = $("[name='checkEntrytestID']:checked").val();
    var entrytest = {
        EntrytestID: id,
        CandidateID: $("[name='CandidateID']").val(),
        Time: $("[name='Times']").val(),
        Date: $("[name='Date']").val(),
        LanguageValuator: $("[name='LanguageValuator']").val(),
        LanguageResult: $("[name='LanguageResult']").val(),
        TechnicalValuator: $("[name='TechnicalValuator']").val(),
        TechnicalResult: $("[name='TechnicalResult']").val(),
        Result: $("[name='Result']").val()
    }

    $.ajax({
        url: "/Candidate/UpdateEntryTest",
        data: JSON.stringify(entrytest),
        method: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (resultMessage) {
            if (resultMessage.Success == true) {
                location.reload(true);
                window.location.href = "/Candidate/Update/" + candidateID + "#entryTest";//"Update?id=" +
            }
        },
        error: function (errorMessage) {
            alert(errorMessage);
        }
    });
}


function updateToTable() {
    if (!validateFields()) {
        return false;

    }
    var checked = $("#radioEntrytestID:checked").val();
    var entrytest = {
        CandidateID: $("[name='CandidateID']").val(),
        Time: checked,
        Date: $("[name='Date']").val(),
        LanguageValuator: $("[name='LanguageValuator']").val(),
        LanguageResult: $("[name='LanguageResult']").val(),
        TechnicalValuator: $("[name='TechnicalValuator']").val(),
        TechnicalResult: $("[name='TechnicalResult']").val(),
        Result: $("[name='Result']").val()
    }
    var sum = 0;

    $.each(entrytests, function (i, item) {
        if (checked == item.Time) {
            entrytests.splice(sum, 1, entrytest);
            $("#tr_" + checked).remove();
            return false;
        }
        sum++;
    })
    $("tr[id^='tr_']").remove();
    $.each(entrytests, function (i, item) {
        $('#entrytestTable tr:last').after('<tr id="tr_' + item.Time + '"><td><input type="radio" name="checkEntrytestID" id="radioEntrytestID" value="' + item.Time + '" onclick=radioEntryTestID(); />'
                  + '<input type="hidden" name="radioDate" id="radioDate_' + item.Time + '" value="' + convertDate(item.Date) + '">'
                  + '<input type="hidden" name="radioLanguageValuator" id="radioLanguageValuator_' + item.Time + '" value="' + item.LanguageValuator + '">'
                  + '<input type="hidden" name="radioLanguageResult" id="radioLanguageResult_' + item.Time + '" value="' + item.LanguageResult + '"></td > <td>'
                  + '<input type="hidden" name="radioTechincalValuator" id="radioTechnicalValuator_' + item.Time + '" value="' + item.TechnicalValuator + '" >'
                  + '<input type="hidden" name="radioTechnicalResult" id="radioTechnicalResult_' + item.Time + '" value="' + item.TechnicalResult + '">'
                  + '<input type="hidden" name="radioResult" id="radioResult_' + item.Time + '" value="' + item.Result + '">'
                  + item.Time + '</td><td>' + convertDate(item.Date) + '</td><td>' + item.LanguageValuator + '</td><td>' + item.LanguageResult + '</td><td>' + item.TechnicalValuator + '</td><td>'
                  + item.TechnicalResult + '</td><td>' + item.Result + '</td></tr>');
    })
    resetData();
}

function resetData() {
    $("[name='Times']").val(countTimes);
    $("[name='LanguageValuator']").val('');
    $("[name='LanguageResult']").val('');
    $("[name='TechnicalValuator']").val('');
    $("[name='TechnicalResult']").val('');
    $("[name='checkEntrytestID']").attr("checked", false);
    $("[name='Result']").val('pass');

    $("[name='btnUpdateToDB']").fadeOut();
    $("[name='btnToReset']").fadeOut();
    $("[name='btnToAdd']").fadeIn();
    $("[name='btnUpdateToTable']").fadeOut();
    $("[name='save']").fadeIn();

    $("[name='EntryTestSaveBtn']").fadeIn();
}

function validateEntryTestMandatory() {
    var check = true;

    if ($("[name='Times']").val() === "") {
        $("[name='Times']").css('border', '1px solid red');
        check = false;
    }
    if ($("[name='Result']").val() === "") {
        $("[name='Result']").css('border', '1px solid red');
        check = false;
    }
    if ($("[name='LanguageResult']").val() === "") {
        $("[name='LanguageResult']").css('border', '1px solid red');
        check = false;
    }
    if ($("[name='TechnicalResult']").val() === "") {
        $("[name='TechnicalResult']").css('border', '1px solid red');
        check = false;
    }
    if (check == false) {
        alert("You must specify a value for this required field.");
    }
    return check;
}

function validateEntryTestFutureDate() {

    var check = true;
    if ($("[name='Date']").val() > getDate()) {
        check = false;
        alert(" 'Date' must not be in the future.");
    }
    return check;
}

function getDate() {
    var d = new Date();
    var strDate;
    var month, date;
    if (d.getMonth() + 1 < 10) {
        var monthTemp = d.getMonth() + 1;
        month = '0' + monthTemp;
    }
    else {
        month = d.getMonth();
    }
    if (d.getDate() < 10) {
        var dateTemp = d.getDate();
        date = '0' + dateTemp;
    }
    else {
        date = d.getDate();
    }
    strDate = d.getFullYear() + "-" + month + "-" + date;
    return strDate;
}

function isNormalInteger(str) {
    return /^\+?(0|[1-9]\d*)$/.test(str);
}

function validateInteger(number) {
    if (isNormalInteger(number) && number >= 0 && number <= 100) {
        return true;
    }
    else {
        alert("The interger number is not format or number > 100 or number < 0");
    }
    return false;
}