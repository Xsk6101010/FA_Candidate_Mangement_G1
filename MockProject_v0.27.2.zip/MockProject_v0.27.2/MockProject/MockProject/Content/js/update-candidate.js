﻿//$('[name="TraineeCandidate.Gender"][value = @Model.TraineeCandidate.Gender]').attr('checked', true);
//$('[name="ChannelID"][Value = @Model.ChannelID]').prop('selected', true);
//$(document).ready(function () {

//    //Location
//    if ($("#location-selector option[Value = '@Model.TraineeCandidate.Location']").length > 0) {
//        $("#location-selector option[Value = '@Model.TraineeCandidate.Location']").prop('selected', true);
//        $("[name='TraineeCandidate.Location']").css("display", "none")
//    }
//    else {
//        $("#location-selector option[Value = 'Other']").prop('selected', true);
//        $("[name='TraineeCandidate.Location']").css("display", "block")
//    }
//    //University
//    if ($("#university-selector option[Value = '@Model.TraineeCandidate.UniversityID']").length > 0) {
//        $("#university-selector option[Value = '@Model.TraineeCandidate.UniversityID']").prop('selected', true);
//        $("[name='TraineeCandidate.Location']").css("display", "none")
//    }
//    else {
//        $("#university-selector option[Value = 'Other']").prop('selected', true);
//        $("[name='TraineeCandidate.UniversityID']").css("display","block")
//    }
//    //Major
//    if ($("#major-selector option[Value = '@Model.TraineeCandidate.MajorID']").length > 0) {
//        $("#major-selector option[Value = '@Model.TraineeCandidate.MajorID']").prop('selected', true);
//        $("[name='TraineeCandidate.MajorID']").css("display", "none")
//    }
//    else {
//        $("#major-selector option[Value = 'Other']").prop('selected', true);
//        $("[name='TraineeCandidate.MajorID']").css("display", "block")
//    }
//    //Skill
//    if ($("#skill-selector option[Value = '@Model.TraineeCandidate.Skill']").length > 0) {
//        $("#skill-selector option[Value = '@Model.TraineeCandidate.Skill']").prop('selected', true);
//        $("[name='TraineeCandidate.Skill']").css("display", "none")
//    }
//    else {
//        $("#skill-selector option[Value = 'Other']").prop('selected', true);
//        $("[name='TraineeCandidate.Skill']").css("display", "block")
//    }
//    //ForeignLanguage
//    if ($("#foreign-language-selector option[Value = '@Model.TraineeCandidate.ForeignLanguage']").length > 0) {
//        $("#foreign-language-selector option[Value = '@Model.TraineeCandidate.ForeignLanguage']").prop('selected', true);
//        $("[name='TraineeCandidate.ForeignLanguage']").css("display", "none")
//    }
//    else {
//        $("#foreign-language-selector option[Value = 'Other']").prop('selected', true);
//        $("[name='TraineeCandidate.ForeignLanguage']").css("display", "block")
//    }
//    //Level
//    if ($("#foreign-language-level-selector option[Value = '@Model.TraineeCandidate.Level']").length > 0) {
//        $("#foreign-language-level-selector option[Value = '@Model.TraineeCandidate.Level']").prop('selected', true);
//        $("[name='TraineeCandidate.Level']").css("display", "none")
//    }
//    else {
//        $("#foreign-language-level-selector option[Value = 'Other']").prop('selected', true);
//        $("[name='TraineeCandidate.Level']").css("display", "block")
//    }
//});