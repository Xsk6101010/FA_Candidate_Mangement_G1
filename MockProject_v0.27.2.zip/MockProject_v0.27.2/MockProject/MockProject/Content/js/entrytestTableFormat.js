﻿$(document).ready(function () {
    $("thead tr th").css({ "background-color": "#B5B5B5" });
    $("tr:odd").css({
        "background-color": "#E8E8E8"
    });
});