﻿$('[name="TraineeCandidate.Gender"]:first').attr('checked', true);
$(function () {
    $('#skill-selector').multiselect({
        includeSelectAllOption: true
    });
});