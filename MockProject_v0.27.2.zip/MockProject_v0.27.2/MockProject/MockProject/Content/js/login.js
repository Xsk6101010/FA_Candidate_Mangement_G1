﻿$(document).ready(function () {
    $("#errUser").css("display", "none");
    $("#errPass").css("display", "none");

    $("[name='username']").keydown(function () {
        $("#errUser").fadeOut();
    });
    $("[name='password']").keydown(function () {
        $("#errPass").fadeOut();
    });
    $("form").submit(function (e) {
        e.preventDefault();

        if (loginFunction() == false) {
            return false;
        }
        else {
            $(this).unbind('submit').submit();
        }
    })

    function loginFunction() {
        var check = true;
        if ($("[name='username']").val() == "") {
            $("#errUser").fadeIn();
            check = false;
        }
        if ($("[name='password']").val() == "") {
            $("#errPass").fadeIn();
            check = false;
        }
        return check;
    }
})