﻿$(document).ready(function () {
        $("#CancelSearchBtn").click(function () {
           window.location.href = '/Candidate/ListCandidate/';
        
        });

        $("#SearchBtn").click(function () {
            var IsChecked = true;
            /*
            if((($("#FullName").val()=='')&&($("#DateOfBirth").val()=='')&&($("#Phone").val()=='')&&("#Email").val()==''))
            {
                return true;
            }
            */
            if ($("#FullName").val() != '' && !validateFullNameLength($("#FullName").val()))
            {                 
                IsChecked= false; 
            }
           
            if ($("[name='DateOfBirth']").val() != '' && !validateDate($("#DateOfBirth").val()))
            {                 
                IsChecked= false; 
            }
           
            if ($("[name='Phone']").val() != '' && !validatePhoneNumber($("#Phone").val()))
            {                 
                IsChecked= false; 
            }
            if ($("[name='Email']").val() != '' && !validateEmail($("#Email").val()))
            {                 
                IsChecked= false; 
            }
            return IsChecked;
        });


       function validateFullNameLength (fullName) {

           if (fullName.length > 30) {
                $("[name = 'Search.FullName.msg17']").show();
                return false;
            }
            else {
                $("[name = 'Search.FullName.msg17']").hide();
                return true;
            }
            
        };
     

      function validatePhoneNumber(phone)  {

            if (isFormatPhoneWithZeroBegin(phone))
            {
                $("[name = 'Search.Phone.msg18']").hide();
                return true;
            }
            else {   
                if (isFormatPhoneMaxLength(phone))
                {
                  $("[name = 'Search.Phone.msg18']").show();              
                  $("[name = 'Search.Phone.msg19']").show();
                  return false;
                }
                else {
                    $("[name = 'Search.Phone.msg19']").hide();
                    return false;
                }
            }      
        }

      function getToday() {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = '0' + dd
            }
            if (mm < 10) {
                mm = '0' + mm
            }
            today = yyyy + '-' + mm + '-' + dd;
            return today;
      }

    
      function validateDate(date)
      {
          if (isFormatDate(date))
          {
              if (date >= getToday()) {
                  $("[name = 'Search.DateOfBirth.msg20']").show();
                  return false;
              }
              else
              {
                  $("[name = 'Search.DateOfBirth.msg20']").hide();
                  return true;
              }
          }         
      }

      function isFormatDate(date)
      {
          if (date === '')
          {
              $("[name = 'Search.DateOfBirth.msg10']").show();
              return false;
          }
          $("[name = 'Search.DateOfBirth.msg10']").hide();
          return true;
      }
    
      function isFormatPhoneWithZeroBegin(number)
      {
        var pattern = new RegExp(/^([+-]?[0-9]\d*|0)$/);
        if(pattern.test(number)&&(String(number).charAt(0)==='0'))
        {
            return true;
        }
        return false;
      }

      function isFormatPhoneMaxLength(number)
      {      
          if (isFormatPhoneWithZeroBegin(number) && (number.length <= 14))
          {
              return true;
          }
          return false;         
      }
  
      function validateEmail(email) {

          var emailReg = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
          if (emailReg.test(email))
          {
              $("[name = 'Search.Email.MSG21']").hide();
              return true;
          }
          else
          {
              $("[name = 'Search.Email.MSG21']").show();
              return false;
          }

      }

/*
        $("#university-selector").change(function () {
            if ($(this).val() === "Other") {
                $("[name = 'TraineeCandidate.UniversityID']").css("display", "block");
                $("[name = 'TraineeCandidate.UniversityID']").val("");
            }
            else {
                $("[name = 'TraineeCandidate.UniversityID']").css("display", "none");
                $("[name = 'TraineeCandidate.UniversityID']").val($(this).val());
            }
        });

        $("#major-selector").change(function () {
            if ($(this).val() === "Other") {
                $("[name = 'TraineeCandidate.MajorID']").css("display", "block")
                $("[name = 'TraineeCandidate.MajorID']").val("");
            }
            else {
                $("[name = 'TraineeCandidate.MajorID']").css("display", "none");
                $("[name = 'TraineeCandidate.MajorID']").val($(this).val());
            }
        });

        $("#skill-selector").change(function () {
            if ($(this).val() === "Other") {
                $("[name = 'TraineeCandidate.Skill']").css("display", "block")
                $("[name = 'TraineeCandidate.Skill']").val("");
            }
            else {
                $("[name = 'TraineeCandidate.Skill']").css("display", "none");
                $("[name = 'TraineeCandidate.Skill']").val($(this).val());
            }
        });

        $("#foreign-language-selector").change(function () {
            if ($(this).val() === "Other") {
                $("[name = 'TraineeCandidate.ForeignLanguage']").css("display", "block")
                $("[name = 'TraineeCandidate.ForeignLanguage']").val("");
            }
            else {
                $("[name = 'TraineeCandidate.ForeignLanguage']").css("display", "none");
                $("[name = 'TraineeCandidate.ForeignLanguage']").val($(this).val());
            }
        });

        $("#foreign-language-level-selector").change(function () {
            if ($(this).val() === "Other") {
                $("[name = 'TraineeCandidate.Level']").css("display", "block")
                $("[name = 'TraineeCandidate.Level']").val("");
            }
            else {
                $("[name = 'TraineeCandidate.Level']").css("display", "none");
                $("[name = 'TraineeCandidate.Level']").val($(this).val());
            }
    });

*/

/*

    function getToday() {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }
        today = yyyy + '-' + mm + '-' + dd;
        return today;
    }

    function validatenumber(number) {
        // 11.99
        var pattern = new RegExp(/^(?=.*\d)\d*(?:\.\d\d)?$/i);

        return pattern.test(number);
    }

    function emailvalidate(email) {
        var b = /^[^@@\s]+@@[^@@\.\s]+(\.[^@@\.\s]+)+$/;
        return b.test(email);
    }


    $("#search").click(function () {
        var isValid = true;

        if ($("[name='fullname']").val().length > 30) {
            $(".fullnameerror").show();
           
            isValid = false;
           
        }

        if ($("[name='dateofbirth']").val() == "" || $("[name='dateofbirth']").val() == undefined) {
            $(".dateofbirtherror10").show();
            isValid = false;
        }

        if ($("[name='dateofbirth']").val() >= getToday()) {
            $(".dateofbirtherror20").show();
            isValid = false;
        }
        return isValid;
    });

    */
});
