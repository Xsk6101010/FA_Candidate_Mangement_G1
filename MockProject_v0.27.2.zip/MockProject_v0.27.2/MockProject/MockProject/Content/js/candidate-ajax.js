﻿$(document).ready(function () {
    $("#candidateInformation form").submit(function (e) {
        e.preventDefault();
        if (checkValidate() == false) {
            return false;
        }

        var candidateInformation = {
            Phone: $('[name="TraineeCandidate.Phone"]').val(),
            Email: $('[name="TraineeCandidate.Email"]').val(),
        };
        var candidate = {
            CandidateID: $('[name="CandidateID"]').val(),
            TraineeCandidate: candidateInformation
        };

        $.ajax({
            url: "/Candidate/CheckPhoneEmail",
            data: JSON.stringify(candidate),
            method: "POST",
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            success: function (result) {
                if (result.HasErrors) {
                    if (result.Errors.isPhoneExisted == true) {
                        $("#phoneExisted").fadeIn();
                        $("[name = 'TraineeCandidate.Phone']").css("border", "1px red solid");
                    }
                    if (result.Errors.isEmailExisted == true) {
                        $("#emailExisted").fadeIn();
                        $("[name = 'TraineeCandidate.Email']").css("border", "1px red solid");
                    }
                }
                else {
                    $("#candidateInformation form").unbind('submit').submit();
                }
            }
        });
    });
})
function checkValidate() {
    $(".error-message").css("display", "none");
    $(".need-validate").css("border", "1px green solid");
    var isValid = true;

    //Validate Name
    if ($("[name = 'TraineeCandidate.FullName']").val() == "") {
        $("#nameEmpty").fadeIn();
        $("[name = 'TraineeCandidate.FullName']").css("border", "1px red solid");
        isValid = false;
    }
    else {
        if ($("[name = 'TraineeCandidate.FullName']").val().length > 30)
        {
            $("[name = 'TraineeCandidate.FullName']").css("border", "1px red solid");
            $("#nameLengthError").fadeIn();
            isValid = false;
        }
    }
    //Validate Channel
    if ($("[name = 'ChannelID']").val() == null) {
        $("#channelEmpty").fadeIn();
        $("[name = 'ChannelID']").css("border", "1px red solid");
        isValid = false;
    }
    //Validate Application Date
    if ($("[name = 'TraineeCandidate.ApplicationDate']").val() == "") {
        $("#applicationEmpty").fadeIn();
        $("[name = 'TraineeCandidate.ApplicationDate']").css("border", "1px red solid");
        isValid = false;
    }
    else {
        if (isFutureDate($("[name = 'TraineeCandidate.ApplicationDate']").val())) {
            $("#applicationFutureError").fadeIn();
            $("[name = 'TraineeCandidate.ApplicationDate']").css("border", "1px red solid");
            isValid = false;
        }
    }
    //Validate Date Of Birth
    if ($("[name = 'TraineeCandidate.DateOfBirth']").val() == "") {
        $("#dobEmpty").fadeIn();
        $("[name = 'TraineeCandidate.DateOfBirth']").css("border", "1px red solid");
        isValid = false;
    }
    else {
        if (isFutureDate($("[name = 'TraineeCandidate.DateOfBirth']").val())) {
            $("#birthDateFutureError").fadeIn();
            $("[name = 'TraineeCandidate.ApplicationDate']").css("border", "1px red solid");
            isValid = false;
        }
    }
    //ValidatePhone
    if ($("[name = 'TraineeCandidate.Phone']").val() == "") {
        $("#phoneEmpty").fadeIn();
        $("[name = 'TraineeCandidate.Phone']").css("border", "1px red solid");
        isValid = false;
    }
    else {
        if($("[name = 'TraineeCandidate.Phone']").val().charAt(0) != "0" )
        {
            $("#phoneStartError").fadeIn();
            $("[name = 'TraineeCandidate.Phone']").css("border", "1px red solid");
            isValid = false;
        }
        if ($("[name = 'TraineeCandidate.Phone']").val().length > 14)
        {
            $("#phoneLengthError").fadeIn();
            $("[name = 'TraineeCandidate.Phone']").css("border", "1px red solid");
            isValid = false;
        }
    }
    //Validate Email
    if ($("[name = 'TraineeCandidate.Email']").val() == "") {
        $("#emailEmpty").fadeIn();
        $("[name = 'TraineeCandidate.Email']").css("border", "1px red solid");
        isValid = false;
    }

    if ($("[name = 'TraineeCandidate.UniversityID']").val() == "") {
        $("#uniEmpty").fadeIn();
        $("#university-selector").css("border", "1px red solid");
        $("[name = 'TraineeCandidate.UniversityID']").css("border", "1px red solid");
        isValid = false;
    }
    return isValid;
}

function isFutureDate(idate) {
    var today = new Date();
    var target = new Date(idate);
    if (target < today)
        return false;
    else
        return true;
}

//function AddCandidate() {
//    if (checkValidate() == false)
//    {
//        return false;
//    }
//    var formData = new FormData();
//    var totalFiles = document.getElementById("FileCV").files.length;
//    for (var i = 0; i < totalFiles; i++) {
//        var file = document.getElementById("FileCV").files[i];
//        formData.append(file.name, file);
//    }
//    //Creating an XMLHttpRequest and sending
//    var xhr = new XMLHttpRequest();
//    xhr.open('POST', '/Candidate/Create');
//    xhr.send(formData);
//    xhr.onreadystatechange = function () {
//        if (xhr.readyState == 4 && xhr.status == 200) {
//            alert(xhr.responseText);
//        }
//    }
//    var candidateInformation = {
//        ApplicationDate: $('[name="TraineeCandidate.ApplicationDate"]').val(),
//        Location: $('[name="TraineeCandidate.Location"]').val(),
//        FullName: $('[name="TraineeCandidate.FullName"]').val(),
//        Gender: $('[name="TraineeCandidate.Gender"]:checked').val(),
//        DateOfBirth: $('[name="TraineeCandidate.DateOfBirth"]').val(),
//        Phone: $('[name="TraineeCandidate.Phone"]').val(),
//        Email: $('[name="TraineeCandidate.Email"]').val(),
//        UniversityID: $('[name="TraineeCandidate.UniversityID"]').val(),
//        MajorID: $('[name="TraineeCandidate.MajorID"]').val(),
//        GraduationYear: $('[name="TraineeCandidate.GraduationYear"]').val(),
//        ForeignLanguage: $('[name="TraineeCandidate.ForeignLanguage"]').val(),
//        Remarks: $('[name="TraineeCandidate.Remarks"]').val(),
//        Type: $('[name="TraineeCandidate.Type"]').val(),
//        FileCV: document.getElementById("FileCV").files[0]
//    };
//    var candidate = {
//        Status: $('[name="TraineeCandidate.Status"]').val(),
//        ChannelID: parseInt($('[name="ChannelID"]').val()),
//        TraineeCandidate: candidateInformation
//    };
//    $.ajax({
//        url: "/Candidate/Create",
//        data: JSON.stringify(formData),
//        method: "POST",
//        contentType: "application/json;charset=utf-8",
//        dataType: "json",
//        success: function (result) {
//            if (result.HasErrors) {
//                if (result.Errors.isPhoneExisted == true) {
//                    $("#phoneExisted").fadeIn();
//                    $("[name = 'TraineeCandidate.Phone']").css("border", "1px red solid");
//                }
//                if (result.Errors.isEmailExisted == true) {
//                    $("#emailExisted").fadeIn();
//                    $("[name = 'TraineeCandidate.Email']").css("border", "1px red solid");
//                }
//                return false;
//            }
//            else {
//                window.location.href = '@Url.Action("ListCandidate", "Candidate")';
//            }
//        },
//        error: function (errormessage) {
//            alert(errormessage.responseText);
//        }
//    });
//}

//function UpdateCandidate() {
//    if (checkValidate() == false)
//    {
//        return false;
//    }
//    var formData = new FormData();
//    var totalFiles = document.getElementById("FileCV").files.length;
//    for (var i = 0; i < totalFiles; i++) {
//        var file = document.getElementById("FileCV").files[i];
//        formData.append("FileUpload", file);
//    }

//    //var candidateInformation = {
//    //    TraineeCandidateID: $('[name="CandidateID"]').val(),
//    //    ApplicationDate: $('[name="TraineeCandidate.ApplicationDate"]').val(),
//    //    Location: $('[name="TraineeCandidate.Location"]').val(),
//    //    FullName: $('[name="TraineeCandidate.FullName"]').val(),
//    //    Gender: $('[name="TraineeCandidate.Gender"]:checked').val(),
//    //    DateOfBirth: $('[name="TraineeCandidate.DateOfBirth"]').val(),
//    //    Phone: $('[name="TraineeCandidate.Phone"]').val(),
//    //    Email: $('[name="TraineeCandidate.Email"]').val(),
//    //    UniversityID: $('[name="TraineeCandidate.UniversityID"]').val(),
//    //    MajorID: $('[name="TraineeCandidate.MajorID"]').val(),
//    //    GraduationYear: $('[name="TraineeCandidate.GraduationYear"]').val(),
//    //    ForeignLanguage: $('[name="TraineeCandidate.ForeignLanguage"]').val(),
//    //    Remarks: $('[name="TraineeCandidate.Remarks"]').val(),
//    //    Type: $('[name="TraineeCandidate.Type"]').val()
//    //};
//    //var candidate = {
//    //    CandidateID: $('[name="CandidateID"]').val(),
//    //    Status: $('[name="TraineeCandidate.Status"]').val(),
//    //    ChannelID: parseInt($('[name="ChannelID"]').val()),
//    //    TraineeCandidate: candidateInformation
//    //};
//    $.ajax({
//        url: "/Candidate/UpdateCandidate",
//        data: JSON.stringify(formData),
//        method: "POST",
//        contentType: "application/json;charset=utf-8",
//        dataType: "json",
//        success: function (result) {
//            if (result.HasErrors) {
//                if (result.Errors.isPhoneExisted == true)
//                {
//                    $("#phoneExisted").fadeIn();
//                    $("[name = 'TraineeCandidate.Phone']").css("border", "1px red solid");
//                }
//                if (result.Errors.isEmailExisted == true)
//                {
//                    $("#emailExisted").fadeIn();
//                    $("[name = 'TraineeCandidate.Email']").css("border", "1px red solid");
//                }
//                return false;
//            }
//            else {
//                window.location.href = "/Candidate/ListCandidate";
//            }
//        }
//    });
//}