﻿using Model;
using System.Collections.Generic;
using System.IO;
using System.Web.Mvc;
using Service;

using Helper;
using System.Web;
using System.Collections;

namespace MockProject.Controllers
{
    public class ImportController : Controller
    {
        IService<Channel> channelService;
        ICandidateService candidateService;
        public ImportController(IService<Channel> channelService, ICandidateService candidateService)
        {
            this.channelService = channelService;
            this.candidateService = candidateService;
        }

        public ActionResult Import()
        {
            return View();
        }

        [HttpPost]
        public ActionResult GetImportedList()
        {
            List<Candidate> importedList = new List<Candidate>();
            for (int i = 0; i < Request.Files.Count; i++)
            {
                var file = Request.Files[i];

                var fileName = Path.GetFileName(file.FileName);

                var path = Path.Combine(HttpRuntime.AppDomainAppPath, @"Content\ImportData\" + fileName);

                file.SaveAs(path);

                importedList = ExcelHelper.ReadFromExcel(path);
            }
            return Json(importedList, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult ImportCandidateList(List<Candidate> candidateList)
        {
            IList resultList = new ArrayList();
            int importCount = 0;
            int rowCount = 1;
            if (candidateList != null)
            {
                foreach (var candidate in candidateList)
                {
                    var check = candidateService.IsExist(candidate.TraineeCandidate.Email, candidate.TraineeCandidate.Phone);
                    if (check.isEmailExisted == true || check.isPhoneExisted == true)
                    {
                        var result = new
                        {
                            row = rowCount,
                            error = true,
                            checkResult = check
                        };
                        resultList.Add(result);
                    }
                    else
                    {
                        candidateService.Add(candidate);
                        var result = new
                        {
                            row = rowCount,
                            error = false
                        };
                        resultList.Add(result);
                        importCount++;
                    }
                    rowCount++;
                }
            }
            return Json(new { Results = resultList,Imported = importCount, Existed = rowCount - 1 - importCount }, JsonRequestBehavior.AllowGet);
        }
    }
}