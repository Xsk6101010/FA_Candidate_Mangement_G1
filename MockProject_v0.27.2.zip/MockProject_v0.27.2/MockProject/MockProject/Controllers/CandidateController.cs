﻿using Helper;
using Model;
using Service;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MockProject.Controllers
{
    public class CandidateController : Controller
    {
        ICandidateService candidateService;
        ITraineeCandidateService traineeCandidateService;
        IService<Channel> channelService;
        IInterviewService interviewService;
        IEntryTestService entryTestService;
        IHistoryService historyService;

        //Constructor
        public CandidateController(ICandidateService candidateService,
                                    ITraineeCandidateService traineeCandidateService,
                                    IService<Channel> channelService,
                                    IInterviewService interviewService,
                                    IEntryTestService entryTestService,
                                    IHistoryService historyService)
        {
            this.candidateService = candidateService;
            this.traineeCandidateService = traineeCandidateService;
            this.channelService = channelService;
            this.interviewService = interviewService;
            this.entryTestService = entryTestService;
            this.historyService = historyService;
        }
        const int DefaultPageSize = 10;
        [LoginRequired]
        public ActionResult ListCandidate(int? pageNumber = 1, int? pageSize = DefaultPageSize)
        {
            int pn = pageNumber ?? default(int);
            int ps = pageSize ?? default(int);
            return View(candidateService.GetAllToPagedList(pn, ps));
        }

        [MyErrorHandler]
        [LoginRequired]
        public ActionResult Create()
        {
            ViewBag.Channels = channelService.GetAll();
            ViewBag.Universities = traineeCandidateService.GetAllDistintUniversity();
            ViewBag.Majors = traineeCandidateService.GetAllDistintMajor();

            return View();
        }

        [LoginRequired]
        public ActionResult Update(int id)
        {
            var candidate = candidateService.GetByID(id);
            return View(candidate);
        }

        [LoginRequired]
        public ActionResult PartialUpdateCandidate(int id)
        {
            var candidate = candidateService.GetByID(id);
            ViewBag.Channels = channelService.GetAll();
            ViewBag.Universities = traineeCandidateService.GetAllDistintUniversity();
            ViewBag.Majors = traineeCandidateService.GetAllDistintMajor();
            return PartialView("PartialUpdateCandidate", candidate);
        }

        [LoginRequired]
        [HttpGet]
        public ActionResult PartialUpdateInterview(int id)
        {
            ViewBag.ID = id;
            var interview = interviewService.GetByCadidateID(id);
            ViewBag.Time = interview.Count + 1;
            return View(interview);
        }

        [LoginRequired]
        [HttpGet]
        public ActionResult PartialUpdateEntryTest(int id)
        {
            ViewBag.ID = id;
            var entrytest = entryTestService.GetByForeignKeyID(id);
            ViewBag.Time = entrytest.Count + 1;
            return View(entrytest);
        }

        [HttpPost]
        [LoginRequired]
        public ActionResult Create(Candidate candidate, HttpPostedFileBase FileCV)
        {
            if (candidate != null)
            {
                if (ModelState.IsValid)
                {
                    candidate = AttachCandidateCVFile(candidate, FileCV);

                    int candidateID = candidateService.Add(candidate);

                    if (candidateID > 0)
                    {
                        AddHistory(candidateID, StringConst.createHistoryText, SessionHelper.GetSession().UserName);
                        int page = candidateService.GetPagePosition(candidateID,DefaultPageSize);
                        return Redirect("/Candidate/ListCandidate?pageNumber="+page);
                    }
                }
            }
            return Json(new { HasErrors = true }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [LoginRequired]
        public ActionResult UpdateCandidate(Candidate candidate, HttpPostedFileBase FileCV)
        {
            if (candidate != null)
            {
                if (ModelState.IsValid)
                {
                    candidate = AttachCandidateCVFile(candidate, FileCV);

                    candidateService.Update(candidate);

                    AddHistory(candidate.CandidateID, StringConst.updateHistoryText, SessionHelper.GetSession().UserName);
                    return RedirectToAction("Update", "Candidate", new { id = candidate.CandidateID });
                }
            }
            return Json(new { HasErrors = true }, JsonRequestBehavior.AllowGet);
        }

        [LoginRequired]
        [HttpPost]
        public ActionResult UpdateInterview(Interview interview)
        {
            try
            {
                interviewService.Update(interview);

                UpdateCandidateStatus(interview.CandidateID, String.Format("Interview - {0}", StringHelper.Capitalize(interview.Result)));

                AddHistory(interview.CandidateID, StringConst.interviewHistoryText + interview.Result, SessionHelper.GetSession().UserName);

                return Json(new { Success = true, Message = MessagesList.MSG29 }, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json(new { Success = false, Message = MessagesList.MSG30 }, JsonRequestBehavior.AllowGet);
            }
        }

        [LoginRequired]
        [HttpPost]
        public ActionResult CreateInterview(List<Interview> interviews)
        {
            try
            {
                foreach (var interview in interviews)
                {
                    interviewService.Add(interview);

                    UpdateCandidateStatus(interview.CandidateID, String.Format("Interview - {0}", StringHelper.Capitalize(interview.Result)));

                    AddHistory(interview.CandidateID, StringConst.interviewHistoryText + interview.Result, SessionHelper.GetSession().UserName);
                }
                return Json(new { Success = true, Message = MessagesList.MSG27 }, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json(new { Success = false, Message = MessagesList.MSG28 }, JsonRequestBehavior.AllowGet);
            }
        }

        [LoginRequired]
        [HttpPost]
        public ActionResult UpdateEntryTest(EntryTest entrytest)
        {
            try
            {
                entryTestService.Update(entrytest);

                UpdateCandidateStatus(entrytest.CandidateID, String.Format("Entry test - {0}", StringHelper.Capitalize(entrytest.Result)));

                AddHistory(entrytest.CandidateID, StringConst.entryTestHistoryText + entrytest.Result, SessionHelper.GetSession().UserName);

                return Json(new { Success = true, Message = "OK" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [LoginRequired]
        [HttpPost]
        public ActionResult CreateEntryTest(List<EntryTest> entrytests)
        {
            try
            {
                foreach (var entrytest in entrytests)
                {
                    entryTestService.Add(entrytest);

                    UpdateCandidateStatus(entrytest.CandidateID, String.Format("Entry test - {0}", StringHelper.Capitalize(entrytest.Result)));

                    AddHistory(entrytest.CandidateID, StringConst.entryTestHistoryText + entrytest.Result, SessionHelper.GetSession().UserName);
                }
                return Json(new { Success = true, Message = "OK" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { Success = false, Message = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }

        [LoginRequired]
        [HttpPost]
        public ActionResult Delete(List<int> candidates)
        {
            try
            {
                foreach (var item in candidates)
                {
                    candidateService.Delete(item);

                    var traineeCandidate = traineeCandidateService.GetByID(item);
                    if (traineeCandidate != null)
                    {
                        traineeCandidateService.Delete(item);
                    }
                }
                return Json(new { Success = true, Message = candidates.Count + " candidates successfully deleted" }, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json(new { Success = false, Message = "Error" }, JsonRequestBehavior.AllowGet);
            }
        }

        [LoginRequired]
        [HttpPost]
        public ActionResult TransferAdd(List<TraineeCandidate> transfers)
        {
            try
            {
                var type = "";
                string template = System.IO.File.ReadAllText(Server.MapPath("~/Content/Template/MailTemplate.html"));
                foreach (var transfer in transfers)
                {
                    type = transfer.Type;
                    traineeCandidateService.Update(transfer);
                    string status = StringConst.transferedHistoryText + type;
                    UpdateCandidateStatus(transfer.TraineeCandidateID, status);

                    AddHistory(transfer.TraineeCandidateID, status, SessionHelper.GetSession().UserName);

                    MailHelper.SendMail(template: template, transfer: transfer);
                }
                return Json(new { Success = true, Message = "OK" }, JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json(new { Success = false, Message = "OK" }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult View(int id)
        {
            var candidate = candidateService.GetByID(id);
            ViewBag.page = candidateService.GetPagePosition(id, DefaultPageSize);
            return View(candidate);
        }

        public ActionResult PartialViewCandidate(int id)
        {
            var candidate = candidateService.GetByID(id);
            return PartialView("PartialUpdateCandidate", candidate);
        }

        public ActionResult PartialViewInterview(int id)
        {
            ViewBag.ID = id;
            var interview = interviewService.GetByCadidateID(id);
            return View(interview);
        }

        public ActionResult PartialViewEntryTest(int id)
        {
            ViewBag.ID = id;
            var interview = interviewService.GetByCadidateID(id);
            return View(interview);
        }

        public JsonResult CheckPhoneEmail(Candidate candidate)
        {
            var original = candidateService.GetByID(candidate.CandidateID);

            var check = candidateService.IsExist(candidate.TraineeCandidate.Email, candidate.TraineeCandidate.Phone);
            if (original != null)
            {
                if (candidate.TraineeCandidate.Email == original.TraineeCandidate.Email)
                    check.isEmailExisted = false;

                if (candidate.TraineeCandidate.Phone == original.TraineeCandidate.Phone)
                    check.isPhoneExisted = false;

                if (check.isEmailExisted || check.isPhoneExisted)
                {
                    return Json(new { HasErrors = true, Errors = check }, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                if (check.isEmailExisted || check.isPhoneExisted)
                {
                    return Json(new { HasErrors = true, Errors = check }, JsonRequestBehavior.AllowGet);
                }
            }

            return Json(new { HasErrors = false }, JsonRequestBehavior.AllowGet);
        }

        private Candidate AttachCandidateCVFile(Candidate candidate, HttpPostedFileBase FileCV)
        {
            if (FileCV != null)
            {
                var filePath = Path.Combine(HttpRuntime.AppDomainAppPath, @"Content\CV\" + FileCV.FileName);
                candidate.TraineeCandidate.FileCV = FileCV;
                candidate.TraineeCandidate.CVFilePath = @"~\Content\CV\" + FileCV.FileName;
                FileCV.SaveAs(filePath);
            }

            return candidate;
        }

        private bool AddHistory(int candidateID, string historyText, string username)
        {
            try
            {
                var history = new History
                {
                    TraineeCandidateID = candidateID,
                    HistoryText = historyText + username,
                    ModifiedUser = username,
                    ModifiedDate = DateTime.Now
                };
                historyService.Add(history);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool UpdateCandidateStatus(int candidateID, string status)
        {
            var candidate = candidateService.GetByID(candidateID);
            candidate.Status = status;
            return candidateService.Update(candidate);
        }
    }
}



