﻿
using Model;
using Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;

namespace MockProject.Controllers
{
    public class TraineeCandidateController : Controller
    {
        private ITraineeCandidateService traineeCandidateService;
        public TraineeCandidateController(ITraineeCandidateService traineeCandidateService)
        {
            this.traineeCandidateService = traineeCandidateService;
        }

        public ActionResult Search()
        {
            return PartialView();
        }
        public ActionResult SearchResult(string fullname, DateTime? dateofbirth, string phone, string email, int? page = 1, int? pagesize = 5)
        {
            IPagedList<CandidateInfo> lstTraineeCandidateService = null;
            try
            {
                var fullName = String.IsNullOrEmpty(fullname) ? "" : fullname.Trim();
                var phoneNumber = String.IsNullOrEmpty(phone) ? "" : phone.Trim();
                var emailCandidate = String.IsNullOrEmpty(email) ? "" : email.Trim();

                lstTraineeCandidateService = traineeCandidateService.Search(fullName, dateofbirth, phoneNumber, emailCandidate, page, pagesize);
                ViewBag.count = lstTraineeCandidateService.TotalItemCount;
                ViewBag.page = page;
                ViewBag.pagesize = pagesize;


                return PartialView("Search", lstTraineeCandidateService);
            }
            catch (Exception ex )
            {
                // log4net.             
            }
            return PartialView();
        }
    }
}
