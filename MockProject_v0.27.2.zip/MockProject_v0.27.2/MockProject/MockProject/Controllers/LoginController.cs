﻿using System.Web.Mvc;
using Service;
using Helper;
using System.Text;

namespace MockProject.Controllers
{
    public class LoginController : Controller
    {
        IUserService service;

        public string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }
        public LoginController(IUserService service)
        {
            this.service = service;
        }
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }
        [HttpPost]
        public ActionResult Login(string username, string password, string returnUrl)
        {
            var user = service.CheckLogin(username, CreateMD5(password));
            if (user != null)
            {
                SessionHelper.SetSession(new UserSession() { UserName = user.Username, Role = user.Role });
                return Redirect(string.IsNullOrEmpty(returnUrl) ? "/" : returnUrl);
            }

            ViewBag.ErrorMessage = "Username or password incorrect";
            return View();
        }
        public ActionResult Logout()
        {
            SessionHelper.SetSession(null);
            return Redirect("Login");
        }
    }
}