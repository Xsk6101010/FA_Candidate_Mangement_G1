﻿using System;
using System.Collections.Generic;
using Model;
using Repository;
namespace Service
{
    public class HistoryService : IHistoryService
    {
        IHistoryRepository historyRepository;
        public HistoryService(IHistoryRepository historyRepository)
        {
            this.historyRepository = historyRepository;
        }
        public int Add(History item)
        {
           return historyRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return historyRepository.Delete(id);
        }

        public List<History> GetAll()
        {
            return historyRepository.GetAll();
        }

        public History GetByID(int id)
        {
            return historyRepository.GetByID(id);
        }

        public History GetByTraineeCandidate(int traineeCandidateID)
        {
            return historyRepository.GetByTraineeCandidate(traineeCandidateID);
        }

        public bool Update(History item)
        {
            return historyRepository.Update(item);
        }
    }
}
