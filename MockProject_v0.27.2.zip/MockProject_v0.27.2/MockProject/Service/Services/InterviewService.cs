﻿using Model;
using Repository;
using System.Collections.Generic;

namespace Service
{
    public class InterviewService : IInterviewService
    {
        private readonly IInterviewRepository interviewRepository;
        public InterviewService(IInterviewRepository interviewRepository)
        {
            this.interviewRepository = interviewRepository;
        }

        public int Add(Interview item)
        {
            return interviewRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return interviewRepository.Delete(id);
        }

        public List<Interview> GetAll()
        {
            return interviewRepository.GetAll();
        }

        public Interview GetByID(int id)
        {
            return interviewRepository.GetByID(id);
        }

        public bool Update(Interview item)
        {
            return interviewRepository.Update(item);
        }
        public List<Interview> GetByCadidateID(int id)
        {
            return interviewRepository.GetByCadidateID(id);
        }
    }
}
