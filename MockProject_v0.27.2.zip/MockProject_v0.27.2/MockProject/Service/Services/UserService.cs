﻿using System.Collections.Generic;
using Model;
using Repository;

namespace Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository userRepository;
        public UserService(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public string Add(User item)
        {
            return userRepository.Add(item);
        }

        public User CheckLogin(string username, string password)
        {
            return userRepository.CheckLogin(username, password);
        }

        public bool Delete(string id)
        {
            return userRepository.Delete(id);
        }

        public List<User> GetAll()
        {
            return userRepository.GetAll();
        }

        public User GetByID(string id)
        {
            return userRepository.GetByID(id);
        }

        public bool Update(User item)
        {
            return userRepository.Update(item);
        }
    }
}
