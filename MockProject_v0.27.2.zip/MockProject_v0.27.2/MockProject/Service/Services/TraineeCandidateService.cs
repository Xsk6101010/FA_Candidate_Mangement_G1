﻿using Model;
using PagedList;
using Repository;
using System;
using System.Collections.Generic;

namespace Service
{
    public class TraineeCandidateService : ITraineeCandidateService
    {
        private ITraineeCandidateRepository traineeCandidateRepository;
        public TraineeCandidateService(ITraineeCandidateRepository traineeCandidateRepository)
        {
            this.traineeCandidateRepository = traineeCandidateRepository;
        }

        public int Add(TraineeCandidate item)
        {
            return traineeCandidateRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return traineeCandidateRepository.Delete(id);
        }

        public List<TraineeCandidate> GetAll()
        {
            return traineeCandidateRepository.GetAll();
        }
        public IPagedList<TraineeCandidate> GetAllPaging(int? page, int? pageSize)
        {
            return traineeCandidateRepository.GetAllPaging(page, pageSize);
        }
        public TraineeCandidate GetByID(int id)
        {
            return traineeCandidateRepository.GetByID(id);
        }

        public bool Update(TraineeCandidate item)
        {
            return traineeCandidateRepository.Update(item);
        }
    
        public IPagedList<CandidateInfo> Search(string fullName, DateTime? dbo, string phone, string email, int? pageNumber, int? pageSize)
        {
            return traineeCandidateRepository.Search(fullName, dbo, phone, email, pageNumber, pageSize);
        }

        public List<string> GetAllDistintUniversity()
        {
            return traineeCandidateRepository.GetAllDistintUniversity();
        }

        public List<string> GetAllDistintMajor()
        {
            return traineeCandidateRepository.GetAllDistintMajor();
        }
    }
}
