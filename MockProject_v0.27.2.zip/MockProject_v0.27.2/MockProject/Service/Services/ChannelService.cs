﻿using Model;
using Repository;
using System.Collections.Generic;

namespace Service
{
    public class ChannelService : IService<Channel>
    {
        private readonly IRepository<Channel> channelRepository;

        public ChannelService(IRepository<Channel> channelRepository)
        {
            this.channelRepository = channelRepository;
        }

        public int Add(Channel item)
        {
            return channelRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return channelRepository.Delete(id);
        }

        public List<Channel> GetAll()
        {
            return channelRepository.GetAll();
        }

        public Channel GetByID(int id)
        {
            return channelRepository.GetByID(id);
        }

        public bool Update(Channel item)
        {
            return channelRepository.Update(item);
        }
    }
}
