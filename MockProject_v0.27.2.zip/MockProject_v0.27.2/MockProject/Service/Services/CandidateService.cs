﻿using Model;
using System.Collections.Generic;
using Repository;
using PagedList;
using System;

namespace Service
{
    public class CandidateService : ICandidateService
    {
        private ICandidateRepository candidateRepository;

        public CandidateService(ICandidateRepository candidateRepository)
        {
            this.candidateRepository = candidateRepository;
        }

        public int Add(Candidate candidate)
        {
            return candidateRepository.Add(candidate);
        }

        public bool Delete(int id)
        {
            return candidateRepository.Delete(id);
        }

        public List<Candidate> GetAll()
        {
            return candidateRepository.GetAll();
        }

        public IPagedList<Candidate> GetAllToPagedList(int pageNumber = 1, int pageSize = 5)
        {
            return candidateRepository.GetAllToPagedList(pageNumber, pageSize);
        }

        public Candidate GetByID(int id)
        {
            return candidateRepository.GetByID(id);
        }

        public int GetPagePosition(int id, int pageSize)
        {
            return candidateRepository.GetPagePosition(id, pageSize);
        }

        public ExistCheckResult IsExist(string email,string phone)
        {
            return candidateRepository.IsExist(email,phone);
        }

        public bool Update(Candidate item)
        {
            return candidateRepository.Update(item);
        }
    }
}
