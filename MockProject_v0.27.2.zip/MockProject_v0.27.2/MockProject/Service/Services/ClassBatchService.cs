﻿using Model;
using Repository;
using System.Collections.Generic;

namespace Service
{
    public class ClassBatchService : IService<ClassBatch>
    {
        private readonly IRepository<ClassBatch> classBatchRepository;

        public ClassBatchService(IRepository<ClassBatch> classBatchRepository)
        {
            this.classBatchRepository = classBatchRepository;
        }

        public int Add(ClassBatch item)
        {
            return classBatchRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return classBatchRepository.Delete(id);
        }

        public List<ClassBatch> GetAll()
        {
            return classBatchRepository.GetAll();
        }

        public ClassBatch GetByID(int id)
        {
            return classBatchRepository.GetByID(id);
        }

        public bool Update(ClassBatch item)
        {
            return classBatchRepository.Update(item);
        }
    }
}
