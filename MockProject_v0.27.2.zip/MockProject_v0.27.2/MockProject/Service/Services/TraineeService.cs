﻿using Model;
using Repository;
using System.Collections.Generic;

namespace Service
{
    public class TraineeService : IService<Trainee>
    {
        private readonly IRepository<Trainee> traineeRepository;
        public TraineeService(IRepository<Trainee> traineeRepository)
        {
            this.traineeRepository = traineeRepository;
        }

        public int Add(Trainee item)
        {
            return traineeRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return traineeRepository.Delete(id);
        }

        public List<Trainee> GetAll()
        {
            return traineeRepository.GetAll();
        }

        public Trainee GetByID(int id)
        {
            return traineeRepository.GetByID(id);
        }

        public bool Update(Trainee item)
        {
            return traineeRepository.Update(item);
        }
    }
}
