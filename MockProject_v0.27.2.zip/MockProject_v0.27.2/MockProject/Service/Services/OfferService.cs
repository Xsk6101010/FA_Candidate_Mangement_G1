﻿using Model;
using Repository;
using System.Collections.Generic;

namespace Service
{
    public class OfferService : IOfferService
    {
        private readonly IOfferRepository offerRepository;
        public OfferService(IOfferRepository offerRepository)
        {
            this.offerRepository = offerRepository;
        }

        public int Add(Offer item)
        {
            return offerRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return offerRepository.Delete(id);
        }

        public List<Offer> GetAll()
        {
            return offerRepository.GetAll();
        }

        public Offer GetByID(int id)
        {
            return offerRepository.GetByID(id);
        }

        public bool Update(Offer item)
        {
            return offerRepository.Update(item);
        }
        public List<Offer> GetByForeignKeyID(int id)
        {
            return offerRepository.GetByForeignKeyID(id);
        }
    }
}
