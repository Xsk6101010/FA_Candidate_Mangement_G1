﻿using Model;
using Repository;
using System.Collections.Generic;
using System;

namespace Service
{
    public class EntryTestService : IEntryTestService
    {
        private readonly IEntryTestRepository entryTestRepository;
        public EntryTestService(IEntryTestRepository entryTestRepository)
        {
            this.entryTestRepository = entryTestRepository;
        }

        public int Add(EntryTest item)
        {
            return entryTestRepository.Add(item);
        }

        public bool Delete(int id)
        {
            return entryTestRepository.Delete(id);
        }

        public List<EntryTest> GetAll()
        {
            return entryTestRepository.GetAll();
        }

        public EntryTest GetByID(int id)
        {
            return entryTestRepository.GetByID(id);
        }

        public bool Update(EntryTest item)
        {
            return entryTestRepository.Update(item);
        }

        public List<EntryTest> GetByForeignKeyID(int id)
        {
            return entryTestRepository.GetByForeignKeyID(id);
        }
    }
}
