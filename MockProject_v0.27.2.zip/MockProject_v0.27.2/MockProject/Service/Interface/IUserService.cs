﻿using System.Collections.Generic;
using Model;

namespace Service
{
    public interface IUserService
    {
        List<User> GetAll();
        User GetByID(string id);
        string Add(User item);
        bool Update(User item);
        bool Delete(string id);
        User CheckLogin(string username, string password);
    }
}
