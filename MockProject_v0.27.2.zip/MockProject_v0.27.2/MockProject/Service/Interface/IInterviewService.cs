﻿using Model;
using System.Collections.Generic;

namespace Service
{
    public interface IInterviewService : IService<Interview>
    {
        List<Interview> GetByCadidateID(int id);
    }
}
