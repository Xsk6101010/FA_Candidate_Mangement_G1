﻿using System.Collections.Generic;

namespace Service
{
    public interface IService<T>
    {
        List<T> GetAll();
        T GetByID(int id);
        int Add(T item);
        bool Update(T item);
        bool Delete(int id);
    }
}
