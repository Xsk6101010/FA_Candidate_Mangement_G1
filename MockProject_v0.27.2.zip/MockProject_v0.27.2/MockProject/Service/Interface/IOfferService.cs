﻿using Model;
using System.Collections.Generic;

namespace Service
{
    public interface IOfferService : IService<Offer>
    {
        List<Offer> GetByForeignKeyID(int id);
    }
}
