﻿using Model;
using PagedList;
using System;

namespace Service
{
    public interface ICandidateService : IService<Candidate>
    {
        ExistCheckResult IsExist(string email,string phone);
        IPagedList<Candidate> GetAllToPagedList(int pageNumber = 1, int pageSize = 5);
        int GetPagePosition(int id, int pageSize);
    }
}
