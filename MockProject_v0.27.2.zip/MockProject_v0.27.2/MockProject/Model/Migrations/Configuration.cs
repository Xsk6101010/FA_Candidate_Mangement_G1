namespace Model.Migrations
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using System.Text;

    internal sealed class Configuration : DbMigrationsConfiguration<CandidateContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }
        string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }
        /// <summary>
        /// Initialize Data , Insert more data for Search and PagedList.
        /// </summary>
        /// <param name="context"></param>
        protected override void Seed(CandidateContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //
            IList<User> users = new List<User>();
            users.Add(new User { Username = "NgocPT5", Password = CreateMD5("123456"), Role = "System Admin" });
            users.Add(new User { Username = "TanPQ", Password = CreateMD5("123456"), Role = "System Admin" });
            users.Add(new User { Username = "hiennv7", Password = CreateMD5("123456"), Role = "System Admin" });
            users.Add(new User { Username = "tiennv25", Password = CreateMD5("123456789"), Role = "System Admin" });

            users.Add(new User { Username = "FARec", Password = CreateMD5("123456"), Role = "FA. Rec" });
            
            users.Add(new User { Username = "Admin", Password = CreateMD5("123456"), Role = "Class Admin" });
            
            users.Add(new User { Username = "Trainer", Password = CreateMD5("123456"), Role = "Trainer" });

            users.Add(new User { Username = "FAManager", Password = CreateMD5("123456"), Role = "FA.Manager" });

            users.Add(new User { Username = "Delivery", Password = CreateMD5("123456"), Role = "Delivery Manager" });

            foreach (var author in users)
            {
                context.Users.AddOrUpdate(author);
            }

            IList<Channel> channels = new List<Channel>();
            channels.Add(new Channel { ChannelID = 1, Remarks = "Good", ChannelName = "FSoft" });
            channels.Add(new Channel { ChannelID = 2, Remarks = "Baddy", ChannelName = "SoftWare" });
            channels.Add(new Channel { ChannelID = 3, Remarks = "Normal", ChannelName = "FPT" });
            channels.Add(new Channel { ChannelID = 4, Remarks = "Good", ChannelName = "FSoft1" });
            channels.Add(new Channel { ChannelID = 5, Remarks = "Baddy", ChannelName = "SoftWare1" });
            channels.Add(new Channel { ChannelID = 6, Remarks = "Normal", ChannelName = "FPT1" });
            foreach (var channel in channels)
            {
                context.Channels.AddOrUpdate(channel);
            }


            IList<ClassBatch> classBatches = new List<ClassBatch>();
            classBatches.Add(new ClassBatch { ClassID = 1, ClassName = ".NET_18_01", ClassCode = "HN_FR_.NET_18_01" });
            classBatches.Add(new ClassBatch { ClassID = 2, ClassName = ".NET_18_02", ClassCode = "HN_FR_.NET_18_02" });
            classBatches.Add(new ClassBatch { ClassID = 3, ClassName = ".NET_18_03", ClassCode = "HN_FR_.NET_18_03" });
            classBatches.Add(new ClassBatch { ClassID = 4, ClassName = ".NET_18_04", ClassCode = "HN_FR_.NET_18_04" });
            classBatches.Add(new ClassBatch { ClassID = 5, ClassName = ".NET_18_05", ClassCode = "HN_FR_.NET_18_05" });
            classBatches.Add(new ClassBatch { ClassID = 6, ClassName = ".NET_18_06", ClassCode = "HN_FR_.NET_18_06" });
            foreach (var author in classBatches)
            {
                context.ClassBatchs.AddOrUpdate(author);
            }
            
            if(!context.TraineeCandidates.Any())
            {
                IList<TraineeCandidate> traineeCandidates = new List<TraineeCandidate>();

                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 1,
                    ApplicationDate = DateTime.Parse("2017/2/1"),
                    Location = "Hanoi",
                    FullName = "Pham Thi Ngoc",
                    DateOfBirth = DateTime.Parse("1996/10/16"),
                    Gender = "Female",
                    UniversityID = "HAUI",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01672401074",
                    Email = "ngocpt5@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "IELTS 7.0",
                    Remarks = "Normal"
                });

                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 2,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Pham Quang Tan",
                    DateOfBirth = DateTime.Parse("1993/1/17"),
                    Gender = "Male",
                    UniversityID = "MTA",
                    MajorID = "IT",
                    GraduationYear = "2018",
                    Phone = "01628372837",
                    Email = "tanpq@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });

                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 3,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Van Tien",
                    DateOfBirth = DateTime.Parse("1987/2/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2016",
                    Phone = "01628372802",
                    Email = "tiennv@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });
                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 4,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Van An",
                    DateOfBirth = DateTime.Parse("1996/10/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01628372801",
                    Email = "annv@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });

                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 5,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Thi B",
                    DateOfBirth = DateTime.Parse("1996/10/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01628372123",
                    Email = "an123@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });
                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 6,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Thi M",
                    DateOfBirth = DateTime.Parse("1996/10/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01628372124",
                    Email = "an124@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });

                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 7,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Thi D",
                    DateOfBirth = DateTime.Parse("1996/10/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01628372125",
                    Email = "an125@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });
                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 8,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Thi C",
                    DateOfBirth = DateTime.Parse("1996/10/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01628372126",
                    Email = "an126@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });

                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 9,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Thi C",
                    DateOfBirth = DateTime.Parse("1996/10/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01628372127",
                    Email = "AN127@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });
                traineeCandidates.Add(new TraineeCandidate
                {
                    TraineeCandidateID = 10,
                    ApplicationDate = DateTime.Parse("2017/10/2"),
                    Location = "Hanoi",
                    FullName = "Nguyen Van An",
                    DateOfBirth = DateTime.Parse("1996/10/2"),
                    Gender = "Male",
                    UniversityID = "DHCNTT",
                    MajorID = "CNTT",
                    GraduationYear = "2017",
                    Phone = "01628372678",
                    Email = "an678@fsoft.com.vn",
                    Skill = "C#",
                    Type = "Candidate",
                    ForeignLanguage = "English",
                    Level = "TOEIC 550",
                    Remarks = "Normal"
                });
                foreach (var traineeCandidate in traineeCandidates)
                {
                    context.TraineeCandidates.AddOrUpdate(traineeCandidate);
                    var candidate = new Candidate
                    {
                        CandidateID = traineeCandidate.TraineeCandidateID,
                        Status = "New",
                        ChannelID = channels[0].ChannelID,
                    };
                    var history = new History
                    {
                        TraineeCandidateID = traineeCandidate.TraineeCandidateID,
                        ModifiedDate = DateTime.Now.Date,
                        ModifiedUser = users[0].Username,
                        HistoryText = "Created by " + users[0].Username
                    };
                    context.Candidates.AddOrUpdate(candidate);
                    context.Histories.AddOrUpdate(history);
                }
            }

/*
           List<Trainee> trainee = new List<Trainee>();
           trainee.Add(new Trainee
           {
               TraineeID = traineeCandidates[0].TraineeCandidateID,
               ClassID = classBatches[0].ClassID,
               Remarks = "Normal"
           });
           trainee.Add(new Trainee
           {
               TraineeID = traineeCandidates[1].TraineeCandidateID,
               ClassID = classBatches[1].ClassID,
               Remarks = "Normal"
           });
           foreach (var author in trainee)
           {
               context.Trainees.AddOrUpdate(author);
           }

           IList<EntryTest> entryTests = new List<EntryTest>();
           entryTests.Add(new EntryTest
           {
               EntryTestID = 1,
               CandidateID = traineeCandidates[0].TraineeCandidateID,
               Time = 2,
               LanguageValuator = "English",
               LanguageResult = 6,
               TechnicalValuator = "C# .NET",
               TechnicalResult = 19,
               Result = "Pass",
               Remarks = ""
           });
           entryTests.Add(new EntryTest
           {
               EntryTestID = 2,
               CandidateID = traineeCandidates[1].TraineeCandidateID,
               Time = 2,
               LanguageValuator = "English",
               LanguageResult = 6,
               TechnicalValuator = "C# .NET",
               TechnicalResult = 22,
               Result = "pass",
               Remarks = "",
           });
           foreach (var author in entryTests)
           {
               context.EntryTests.AddOrUpdate(author);
           }

           IList<Offer> offers = new List<Offer>();
           offers.Add(new Offer
           {
               OfferID = 1,
               CandidateID = traineeCandidates[0].TraineeCandidateID,
               Jobrank = 7,
               Technology = "C# .NET",
               ContractType = "Short-term",
               OfferSalary = 230000,
               Remarks = ""
           });
           offers.Add(new Offer
           {
               OfferID = 2,
               CandidateID = traineeCandidates[0].TraineeCandidateID,
               Jobrank = 8,
               Technology = "C# .NET",
               ContractType = "Short-term",
               OfferSalary = 230000,
               Remarks = ""
           });
           offers.Add(new Offer
           {
               OfferID = 3,
               CandidateID = traineeCandidates[1].TraineeCandidateID,
               Jobrank = 9,
               Technology = "C# .NET",
               ContractType = "Short-term",
               OfferSalary = 280000,
               Remarks = ""
           });
           foreach (var author in offers)
           {
               context.Offers.AddOrUpdate(author);
           }


           IList<Interview> interviews = new List<Interview>();
           interviews.Add(new Interview
           {
               InterviewID = 1,
               CandidateID = traineeCandidates[0].TraineeCandidateID,
               Time = 1,
               Date = DateTime.Parse("2/5/2017"),
               Interviewer = "Interviewer 1",
               Comments = "Good",
               Result = "pass",
               Remarks = ""
           });
           interviews.Add(new Interview
           {
               InterviewID = 2,
               CandidateID = traineeCandidates[0].TraineeCandidateID,
               Time = 2,
               Date = DateTime.Parse("7/7/2017"),
               Interviewer = "Interviewer 2",
               Comments = "Badly",
               Result = "failes",
               Remarks = ""
           });
           interviews.Add(new Interview
           {
               InterviewID = 3,
               CandidateID = traineeCandidates[0].TraineeCandidateID,
               Time = 3,
               Date = DateTime.Parse("7/3/2017"),
               Interviewer = "Interviewer 2",
               Comments = "Good",
               Result = "pass",
               Remarks = ""
           });
           foreach (var author in interviews)
           {
               context.Interviews.AddOrUpdate(author);
           }
*/
            base.Seed(context);
        }
    }
}
