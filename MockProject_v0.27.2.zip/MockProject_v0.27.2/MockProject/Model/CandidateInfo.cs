﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
   public class CandidateInfo
    {
        [Required]
        public DateTime? ApplicationDate { get; set; }
        [Required]
        public string Location { get; set; }
        [Required]
        public string FullName { get; set; }
        [Required]
        public string Type { get; set; }
        [Required]
        public DateTime? DateOfBirth { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required]
        public string Phone { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string UniversityID { get; set; }

        [Required]
        public string MajorID { get; set; }
        [Required]
        public string Channel { get; set; }
        [Required]
        public string Skill { get; set; }
        [Required]
        public string GraduationYear { get; set; }
        [Required]
        public string ForeignLanguage { get; set; }
        [Required]
        public string Level { get; set; }
        public string Status { get; set; }
    }
}
