﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{
    public class Interview
    {
        [Key]
        public int InterviewID { get; set; }

        [ForeignKey("Candidate")]
        public int CandidateID { get; set; }

        public int Time { get; set; }

        public DateTime Date { get; set; }

        [StringLength(50)]
        public string Interviewer { get; set; }

        [StringLength(200)]
        public string Comments { get; set; }

        [StringLength(50)]
        public string Result { get; set; }

        [StringLength(50)]
        public string Remarks { get; set; }

        public virtual Candidate Candidate { get; set; }
    }
}
