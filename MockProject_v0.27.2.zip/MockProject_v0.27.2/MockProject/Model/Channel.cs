﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{
    public class Channel
    {
        [Key]
        public int ChannelID { get; set; }
        [StringLength(200)]
        public string Remarks { get; set; }
        [StringLength(50)]
        public string ChannelName { get; set; }

        public virtual ICollection<Candidate> Candidate { get; set; }        
    }
}
