﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{
    public class ClassBatch
    {
        [Key]
        public int ClassID { get; set; }

        [Column(TypeName = "NVARCHAR")]
        [Index("IDX_Class_Name",IsClustered = false,IsUnique = true)]
        [MaxLength(50)]
        public string ClassName { get; set; }

        [Column(TypeName = "VARCHAR")]
        [Index("IDX_Class_Code", IsClustered = false, IsUnique = true)]
        [MaxLength(50)]
        public string ClassCode { get; set; }

        public virtual ICollection<Trainee> Trainees { get; set; }
    }
}
