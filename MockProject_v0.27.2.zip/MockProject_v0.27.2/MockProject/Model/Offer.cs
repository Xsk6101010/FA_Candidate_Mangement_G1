﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{
    public class Offer
    {
        [Key]
        public int OfferID { get; set; }

        [ForeignKey("Candidate")]
        public int CandidateID { get; set; }
        public int Jobrank { get; set; }
        [StringLength(50)]
        public string Technology { get; set; }
        [StringLength(50)]
        public string ContractType { get; set; }
        public decimal OfferSalary { get; set; }
        [StringLength(200)]
        public string Remarks { get; set; }

        public virtual Candidate Candidate { get; set; }
    }
}
