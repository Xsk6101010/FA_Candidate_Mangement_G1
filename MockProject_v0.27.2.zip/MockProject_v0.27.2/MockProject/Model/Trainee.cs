﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{
    public class Trainee
    {
        [Key]
        [ForeignKey("TraineeCandidate")]
        public int TraineeID { get; set;}

        [ForeignKey("ClassBatch")]
        public int ClassID { get; set; }

        public string Remarks { get; set; }
        public virtual TraineeCandidate TraineeCandidate { get; set; }
        public virtual ClassBatch ClassBatch { get; set; }
    }
}
