﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Model
{

    public class Candidate
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [ForeignKey("TraineeCandidate")]
        public int CandidateID { get; set; }

        public string Status { get; set; }

        [ForeignKey("Channel")]
        public int ChannelID { get; set; }
        public virtual TraineeCandidate TraineeCandidate { get; set; }
        public virtual ICollection<Interview> Interview { get; set; }
        public virtual Channel Channel { get; set; }
        public virtual ICollection<EntryTest> EntryTest { get; set; }
        public virtual ICollection<Offer> Offer { get; set; }
    }
}
