﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class History
    {
        [Key]
        public int HistoryID { get; set; }

        [ForeignKey("TraineeCandidate")]
        public int TraineeCandidateID { get; set; }

        public string HistoryText { get; set; }

        public DateTime? ModifiedDate { get; set; }

        [ForeignKey("User")]
        public string ModifiedUser { get; set; }

        public virtual TraineeCandidate TraineeCandidate { get; set; }

        public virtual User User { get; set; }
    }   
}
