﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web;

namespace Model
{
    public class TraineeCandidate
    {
        [Key]
        public int TraineeCandidateID { get; set; }

        public DateTime? ApplicationDate { get; set; }

        public string Location { get; set; }

        [Required]
        [StringLength(50)]
        public string FullName { get; set; }

        public DateTime? DateOfBirth { get; set; }

        [Required]
        [StringLength(10)]
        public string Gender { get; set; }

        //   [Required]
        [StringLength(10)]
        public string UniversityID { get; set; }

        //   [Required]
        [StringLength(10)]
        public string MajorID { get; set; }

        //[Required]
        public string GraduationYear { get; set; }

        [Required]
        [StringLength(20)]
        [Index("IDX_Phone_Number", IsClustered = false, IsUnique = true)]
        public string Phone { get; set; }

        [Required]
        [StringLength(50)]
        [Index("IDX_Email_Address", IsClustered = false, IsUnique = true)]
        public string Email { get; set; }

        //Candidate - Trainee
        //[Required]
        [StringLength(50)]
        public string Type { get; set; }
        //   [Required]
        [StringLength(50)]
        public string Skill { get; set; }
        //[Required]
        [StringLength(50)]
        public string ForeignLanguage { get; set; }

        //Foreign Language Level, i.e IELTS 7.0
        public string Level { get; set; }

        [StringLength(50)]
        public string Remarks { get; set; }

        [NotMapped]
        public HttpPostedFileBase FileCV { get; set; }

        public string CVFilePath { get; set; }

        public string Position { get; set; }

        public virtual Candidate Candidate { get; set; }

        public virtual Trainee Trainee { get; set; }

        public virtual ICollection<History> History { get; set; }
    }
}
