﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    [Table("EntryTest")]
    public class EntryTest
    {
        [Key]
        public int EntryTestID { get; set; }

        [ForeignKey("Candidate")]
        public int CandidateID { get; set; }

        public int Time { get; set; }

        [StringLength(50)]
        public string LanguageValuator {get;set;}

        [Range(0,100)]
        public int LanguageResult { get; set; }

        [StringLength(50)]
        public string TechnicalValuator { get; set; }

        [Range(0, 100)]
        public int TechnicalResult { get; set; }

        [StringLength(10)]
        public string Result { get; set; }

        [StringLength(100)]
        public string Remarks { get; set; }

        public DateTime? Date { get; set; }

        public virtual Candidate Candidate { get; set; }

    }
}
