﻿using System.Data.Entity;

namespace Model
{
    public class CandidateContext : DbContext
    {
        public CandidateContext() : base("name=HN_FR_.NET_18_04_G1_CandidateManagement")
        {
            Database.SetInitializer<CandidateContext>(new MigrateDatabaseToLatestVersion<CandidateContext, Migrations.Configuration>());
        }

        public DbSet<Candidate> Candidates { get; set; }
        public DbSet<Channel> Channels { get; set; }
        public DbSet<ClassBatch> ClassBatchs{ get; set; }

        public DbSet<EntryTest> EntryTests{ get; set; }
        public DbSet<Interview> Interviews { get; set; }
        public DbSet<Offer> Offers { get; set; }

        public DbSet<Trainee> Trainees { get; set; }
        public DbSet<TraineeCandidate> TraineeCandidates { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<History> Histories { get; set; }
    }
}
