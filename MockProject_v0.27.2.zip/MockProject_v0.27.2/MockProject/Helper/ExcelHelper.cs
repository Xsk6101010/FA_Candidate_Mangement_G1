﻿using Model;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Helper
{
    public class ExcelHelper
    {
        public static List<Candidate> ReadFromExcel(string path)
        {
            List<Candidate> candidates = new List<Candidate>();
            using (var pck = new ExcelPackage())
            {
                using (var stream = File.OpenRead(path))
                {
                    pck.Load(stream);
                }

                var workSheet = pck.Workbook.Worksheets.FirstOrDefault();
                int column = 16;
                List<string> columnNames = new List<string>();

                foreach (var cell in workSheet.Cells[1, 1, 1, column])
                {
                    if (cell.Value != null && cell.Value.ToString().Length < 256)
                    {
                        columnNames.Add(cell.Value.ToString());
                    }
                }

                for(var rowNum = 2;rowNum <= workSheet.Dimension.End.Row;rowNum++)
                {
                    var wsRow = workSheet.Cells[rowNum, 1, rowNum, column];
                    var information = new TraineeCandidate
                    {
                        FullName = wsRow[rowNum, 1].Value.ToString(),
                        ApplicationDate = DateTime.Parse(wsRow[rowNum, 2].Value.ToString()),
                        DateOfBirth = DateTime.Parse(wsRow[rowNum, 3].Value.ToString()),
                        Phone = wsRow[rowNum, 4].Value.ToString(),
                        Email = wsRow[rowNum, 5].Value.ToString(),
                        Gender = wsRow[rowNum, 6].Value.ToString(),
                        Location = wsRow[rowNum, 7].Value != null ? wsRow[rowNum, 7].Value.ToString() : String.Empty,
                        UniversityID = wsRow[rowNum, 8].Value != null ? wsRow[rowNum, 8].Value.ToString() : String.Empty,
                        MajorID = wsRow[rowNum, 9].Value != null ? wsRow[rowNum, 9].Value.ToString() : String.Empty,
                        Skill = wsRow[rowNum, 10].Value != null ? wsRow[rowNum, 10].Value.ToString() : String.Empty,
                        GraduationYear = wsRow[rowNum, 11].Value != null ? wsRow[rowNum, 11].Value.ToString() : String.Empty,
                        ForeignLanguage = wsRow[rowNum, 12].Value != null ? wsRow[rowNum, 12].Value.ToString() : String.Empty,
                        Level = wsRow[rowNum, 13].Value != null ? wsRow[rowNum, 13].Value.ToString() : String.Empty,
                        Type = wsRow[rowNum, 14].Value != null ? wsRow[rowNum, 14].Value.ToString() : "Candidate"
                    };
                    
                    var candidate = new Candidate
                    {
                        ChannelID = Convert.ToInt32(wsRow[rowNum, 15].Value),
                        Status = wsRow[rowNum, 16].Value != null ? wsRow[rowNum, 16].Value.ToString() : "New",
                        TraineeCandidate = information
                    };
                    candidates.Add(candidate);
                }
            }
            return candidates;
        }
        

        //public static void ExportCustomertoExcel (List<Customer> customers)
        //{
        //    using(ExcelPackage package = new ExcelPackage())
        //    {
        //        ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Customers");
        //        int index = 2;

        //        foreach (var item in customers)
        //        {
        //            worksheet.Cells["A" + index].Value = item.RMid;
        //            //worksheet.Cells["A" + index].Style.Border
        //            worksheet.Cells["B" + index].Value = item.RMname;
        //            SetCellStyle(worksheet.Cells["B" + index], ExcelBorderStyle.Thick, Color.Red);
        //            worksheet.Cells["C" + index].Value = item.id;
        //            worksheet.Cells["D" + index].Value = item.name;
        //            worksheet.Cells["E" + index].Value = item.address;
        //            worksheet.Cells["F" + index].Value = item.email;
        //            worksheet.Cells["G" + index].Value = item.sector;
        //            worksheet.Cells["H" + index].Value = item.type;
        //            worksheet.Cells["I" + index].Value = item.ngaygoi;
        //            var cells = worksheet.Cells[1, 1, 5, 5];
        //            index++;
        //        }
        //        worksheet.Column(1).AutoFit();
        //        worksheet.Column(2).AutoFit();
        //        worksheet.Column(3).AutoFit();
        //        worksheet.Column(4).AutoFit();
        //        worksheet.Column(5).AutoFit();
        //        worksheet.Column(6).AutoFit();
        //        worksheet.Column(7).AutoFit();
        //        worksheet.Column(8).AutoFit();
        //        worksheet.Column(9).AutoFit();
        //        string path = @"E:\customer.xlsx";
        //        Stream stream = File.Create(path);
        //        package.SaveAs(stream);
        //        stream.Close();
        //    }   
        //}

        //private static void SetCellStyle(ExcelRange cell, ExcelBorderStyle border, Color color)
        //{
        //    cell.Style.Border.Top.Style = border;
        //    cell.Style.Border.Left.Style = border;
        //    cell.Style.Border.Right.Style = border;
        //    cell.Style.Border.Bottom.Style = border;
        //    cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
        //    cell.Style.Fill.BackgroundColor.SetColor(color);

        //}
    }
}
