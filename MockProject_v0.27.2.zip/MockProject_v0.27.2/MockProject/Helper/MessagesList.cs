﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    public static class MessagesList
    {
        public const string MSG1 = "Invalid user name";
        public const string MSG2 = "Invalid password";
        public const string MSG3 = "User name is empty";
        public const string MSG4 = "Password is empty.";
        public const string MSG5 = "You must specify a value for this required field.";
        public const string MSG6 = "Maximum character number allowed is 30.";

        public const string MSG10 = "The date time format should be: DD/MM/YYYY.";
        public const string MSG11 = "Please input number only.";

        public const string MSG14 = "Nothing found.";
        public const string MSG15 = "Please input one criteria only.";
        public const string MSG16 = "Application Date must not be in the future.";
        public const string MSG17 = "The max length of this field is 30.";
        public const string MSG18 = "You must start phone number with “0”.";
        public const string MSG19 = "The max length of this field is 14.";
        public const string MSG20 = "Date of birth” must not be in the future.";
        public const string MSG21 = "You must input email as email format.Ex: abc @xyz.com...";
        public const string MSG22 = "This Candidate Information has been already inputted.";
        public const string MSG23 = "“Date” must not be in the future.";
        public const string MSG24 = "You must input Candidate Information first.";
        public const string MSG25 = "You must input Candidate Entry Test result first.";
        public const string MSG26 = "You must to select a file.";
        public const string MSG27 = "Successfully created";
        public const string MSG28 = "New creation failed.";
        public const string MSG29 = "Successfully created";
        public const string MSG30 = "New creation failed.";
        public const string MSGPhoneExisted = "Phone number already existed in database";
        public const string MSGEmailExisted = "Email address already existed in database";
    }
}
