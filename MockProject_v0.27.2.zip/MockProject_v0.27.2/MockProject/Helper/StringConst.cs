﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    public static class StringConst
    {
        public const string fullNamePlaceholder = "{{FullName}}";
        public const string typePlaceholder = "{{Type}}";
        public const string linkPlaceholder = "{{Link}}";

        public const string createHistoryText = "Created by ";
        public const string updateHistoryText = "Updated by ";
        public const string entryTestHistoryText = "Entry test - ";
        public const string interviewHistoryText = "Interview - ";
        public const string transferedHistoryText = "Transfered to ";
    }
}
