﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    public class LogHelper
    {
        public static readonly LogHelper instance = new LogHelper();
        private ILog logger;

        private LogHelper()
        {
            logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }
        /// <summary>  
        /// Used to log Debug messages in an explicit Debug Logger  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        public void Debug(string message)
        {
            instance.logger.Debug(message);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        /// <param name="exception">The exception to log, including its stack trace </param>  
        public void Debug(string message, System.Exception exception)
        {
            instance.logger.Debug(message, exception);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        public void Info(string message)
        {
            instance.logger.Info(message);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        /// <param name="exception">The exception to log, including its stack trace </param>  
        public void Info(string message, System.Exception exception)
        {
            instance.logger.Info(message, exception);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        public void Warn(string message)
        {
            instance.logger.Warn(message);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        /// <param name="exception">The exception to log, including its stack trace </param>  
        public void Warn(string message, System.Exception exception)
        {
            instance.logger.Warn(message, exception);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        public void Error(string message)
        {
            instance.logger.Error(message);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        /// <param name="exception">The exception to log, including its stack trace </param>  
        public void Error(string message, System.Exception exception)
        {
            instance.logger.Error(message, exception);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        public void Fatal(string message)
        {
            instance.logger.Fatal(message);
        }
        /// <summary>  
        ///  
        /// </summary>  
        /// <param name="message">The object message to log</param>  
        /// <param name="exception">The exception to log, including its stack trace </param>  
        public void Fatal(string message, System.Exception exception)
        {
            instance.logger.Fatal(message, exception);
        }
    }
}
