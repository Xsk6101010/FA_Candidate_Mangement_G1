﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Helper
{
    public static class MultiselectBox
    {
        public static MvcHtmlString Multiselect(this HtmlHelper helper, List<string> options)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("<div class='box-wrapper'>");
            foreach(var option in options)
            {
                builder.Append(String.Format("<div class='select-row'><input type='checkbox' value = '{0}' name = 'skill'/><label>{1}</label></div>", option, option));
            }
            builder.Append("</div>");
            return new MvcHtmlString(builder.ToString());
        }
    }
}
