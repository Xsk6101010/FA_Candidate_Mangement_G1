﻿using System.Web.Routing;
using System.Web.Mvc;
using System.Web;

namespace Helper
{
    public class LoginRequiredAttribute : AuthorizeAttribute
    {
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Session["loggedUser"] == null)
            {
                filterContext.Result = new RedirectToRouteResult(new
                RouteValueDictionary(new { area = string.Empty, controller = "Login", action = "Login", redirectUrl = HttpContext.Current.Request.Url.PathAndQuery }));
            }
            if (filterContext.HttpContext.Session["loggedUser"] != null)
            {
                var user = (UserSession)filterContext.HttpContext.Session["loggedUser"];
                var routeData = filterContext.HttpContext.Request.RequestContext.RouteData;
                string currentAction = routeData.GetRequiredString("action");
                string currentController = routeData.GetRequiredString("controller");
                string currentArea = routeData.Values["area"] as string;
                if (user.Role != "System Admin" && user.Role != "FA. Rec" && user.Role != "FA.Manager")
                {
                    if (currentController == "Candidate" && (currentAction == "Create" || currentAction == "Update" || currentAction == "View"))
                    { 
                        filterContext.Result = new RedirectToRouteResult(new
                        RouteValueDictionary(new { area = string.Empty, controller = "Login", action = "Login", message = "Access denies", redirectUrl = HttpContext.Current.Request.Url.PathAndQuery }));
                    }
                    if (currentController == "Import" && currentAction == "Import")
                    {
                        filterContext.Result = new RedirectToRouteResult(new
                        RouteValueDictionary(new { area = string.Empty, controller = "Login", action = "Login", message = "Access denies", redirectUrl = HttpContext.Current.Request.Url.PathAndQuery }));
                    }
                }
            }
        }
    }
}
