﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Helper
{
    public class StringHelper
    {
        public static string Capitalize(string value)
        {
            char[] array = value.ToCharArray();
            // Handle the first letter in the string.
            if (array.Length >= 1)
            {
                if (char.IsLower(array[0]))
                {
                    array[0] = char.ToUpper(array[0]);
                }
            }
            // Scan through the letters, checking for spaces.
            // ... Uppercase the lowercase letters following spaces.
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i - 1] == ' ')
                {
                    if (char.IsLower(array[i]))
                    {
                        array[i] = char.ToUpper(array[i]);
                    }
                }
            }
            return new string(array);
        }

        public static List<string> FilterEmptyString(List<string> input)
        {
            List<string> result = new List<string>();
            foreach(var item in input)
            {
                if(!String.IsNullOrWhiteSpace(item))
                {
                    result.Add(item);
                }
            }
            return result;
        }

        public static List<string> SplitDistintString(List<string> input)
        {
            List<string> result = new List<string>();
            foreach(var item in input)
            {
                string[] splice = item.Split(',');
                for(int i=0;i<splice.Length;i++)
                {
                    if(!String.IsNullOrWhiteSpace(splice[i]))
                    {
                        if(!result.Contains(splice[i]))
                        {
                            result.Add(splice[i]);
                        }
                    }
                }
            }
            return result;
        }
    }
}
