﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class TraineeRepositoryTests
    {
        private IRepository<Trainee> repository = new TraineeRepository();
        private IRepository<ClassBatch> repositoryClassBatch = new ClassBatchRepository();
        private IRepository<TraineeCandidate> repositoryTraineeCandidate = new TraineeCandidateRepository();
        
        [TestMethod]
        public void AddTest()
        {
            var Trainee = new Trainee
            {
                TraineeID = 1, // repositoryTraineeCandidate.GetAll().FirstOrDefault().TraineeCandidateID,
                ClassID = repositoryClassBatch.GetAll().FirstOrDefault().ClassID,
                Remarks = "Remarks"
            };
            var resultId = repository.Add(Trainee);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(Trainee.TraineeID, newadded.TraineeID);
            Assert.AreEqual(Trainee.ClassID, newadded.ClassID);
            Assert.AreEqual(Trainee.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 1; // repositoryTraineeCandidate.GetAll().FirstOrDefault().TraineeCandidateID;
            var newadded = repository.GetByID(id);
            newadded.ClassID = repositoryClassBatch.GetAll().FirstOrDefault().ClassID;
            newadded.Remarks = "Remarks new";

            repository.Update(newadded);

            var updated = repository.GetByID(id);


            Assert.AreEqual(updated.TraineeID, newadded.TraineeID);
            Assert.AreEqual(updated.ClassID, newadded.ClassID);
            Assert.AreEqual(updated.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var Trainee = new Trainee
            {
                TraineeID = 2, // repositoryTraineeCandidate.GetAll().FirstOrDefault().TraineeCandidateID,
                ClassID = repositoryClassBatch.GetAll().FirstOrDefault().ClassID,
                Remarks = "Remarks"
            };

            var resultId = repository.Add(Trainee);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(Trainee.TraineeID, newadded.TraineeID);
            Assert.AreEqual(Trainee.ClassID, newadded.ClassID);
            Assert.AreEqual(Trainee.Remarks, newadded.Remarks);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = repositoryTraineeCandidate.GetAll().FirstOrDefault().TraineeCandidateID;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }
    }
}