﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class EntryTestRepositoryTests
    {
        private IEntryTestRepository repository = new EntryTestRepository();
        private ICandidateRepository repositoryCandidate;// = new CandidateRepository();
        [TestInitialize]
        public void Initilize()
        {
            ITraineeCandidateRepository repositoryTraineeCandidate = new TraineeCandidateRepository();
            this.repositoryCandidate = new CandidateRepository(repositoryTraineeCandidate);
        }
        [TestMethod]
        public void AddTest()
        {
            var entryTest = new EntryTest
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Time = 1,
                LanguageValuator = "LanguageValuator",
                LanguageResult = 1,
                TechnicalValuator = "TechnicalValuator",
                TechnicalResult = 1,
                Result = "Result",
                Remarks = "Remarks"
            };
            var resultId = repository.Add(entryTest);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(entryTest.CandidateID, newadded.CandidateID);
            Assert.AreEqual(entryTest.Time, newadded.Time);
            Assert.AreEqual(entryTest.LanguageValuator, newadded.LanguageValuator);
            Assert.AreEqual(entryTest.LanguageResult, newadded.LanguageResult);
            Assert.AreEqual(entryTest.TechnicalValuator, newadded.TechnicalValuator);
            Assert.AreEqual(entryTest.TechnicalResult, newadded.TechnicalResult);
            Assert.AreEqual(entryTest.Result, newadded.Result);
            Assert.AreEqual(entryTest.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 1;
            var newadded = repository.GetByID(id);
            newadded.CandidateID = 1;
            newadded.Time = 1;
            newadded.LanguageValuator = "LanguageValuator";
            newadded.LanguageResult = 1;
            newadded.TechnicalValuator = "TechnicalValuator";
            newadded.TechnicalResult = 1;
            newadded.Result = "Result";
            newadded.Remarks = "Remarks";

            repository.Update(newadded);

            var updated = repository.GetByID(id);


            Assert.AreEqual(updated.CandidateID, newadded.CandidateID);
            Assert.AreEqual(updated.Time, newadded.Time);
            Assert.AreEqual(updated.LanguageValuator, newadded.LanguageValuator);
            Assert.AreEqual(updated.LanguageResult, newadded.LanguageResult);
            Assert.AreEqual(updated.TechnicalValuator, newadded.TechnicalValuator);
            Assert.AreEqual(updated.TechnicalResult, newadded.TechnicalResult);
            Assert.AreEqual(updated.Result, newadded.Result);
            Assert.AreEqual(updated.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var entryTest = new EntryTest
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Time = 1,
                LanguageValuator = "LanguageValuator",
                LanguageResult = 1,
                TechnicalValuator = "TechnicalValuator",
                TechnicalResult = 1,
                Result = "Result",
                Remarks = "Remarks"
            };

            var resultId = repository.Add(entryTest);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(entryTest.CandidateID, newadded.CandidateID);
            Assert.AreEqual(entryTest.Time, newadded.Time);
            Assert.AreEqual(entryTest.LanguageValuator, newadded.LanguageValuator);
            Assert.AreEqual(entryTest.LanguageResult, newadded.LanguageResult);
            Assert.AreEqual(entryTest.TechnicalValuator, newadded.TechnicalValuator);
            Assert.AreEqual(entryTest.TechnicalResult, newadded.TechnicalResult);
            Assert.AreEqual(entryTest.Result, newadded.Result);
            Assert.AreEqual(entryTest.Remarks, newadded.Remarks);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = repository.GetAll().FirstOrDefault().EntryTestID;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }
        [TestMethod]
        public void GetByForeignKeyIDTest()
        {
            var resultId = repositoryCandidate.GetAll().FirstOrDefault().CandidateID;

            var all = repository.GetByForeignKeyID(resultId);
            int total1 = all.Count;
            var entryTest = new EntryTest
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Time = 1,
                LanguageValuator = "LanguageValuator",
                LanguageResult = 1,
                TechnicalValuator = "TechnicalValuator",
                TechnicalResult = 1,
                Result = "Result",
                Remarks = "Remarks"
            };

            var offers = repository.Add(entryTest);

            var newadded = repository.GetByID(offers);

            Assert.AreEqual(entryTest.CandidateID, newadded.CandidateID);
            Assert.AreEqual(entryTest.Time, newadded.Time);
            Assert.AreEqual(entryTest.LanguageValuator, newadded.LanguageValuator);
            Assert.AreEqual(entryTest.LanguageResult, newadded.LanguageResult);
            Assert.AreEqual(entryTest.TechnicalValuator, newadded.TechnicalValuator);
            Assert.AreEqual(entryTest.TechnicalResult, newadded.TechnicalResult);
            Assert.AreEqual(entryTest.Result, newadded.Result);
            Assert.AreEqual(entryTest.Remarks, newadded.Remarks);

            var allafteradded = repository.GetByForeignKeyID(resultId);
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);
        }
    }
}