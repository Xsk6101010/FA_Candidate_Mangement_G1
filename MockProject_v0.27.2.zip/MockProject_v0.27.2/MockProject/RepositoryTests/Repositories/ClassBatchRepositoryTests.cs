﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class ClassBatchRepositoryTests
    {
        private IRepository<ClassBatch> repository = new ClassBatchRepository();

        [TestMethod]
        public void AddTest()
        {
            var classBatch = new ClassBatch
            {
                ClassName = "Name",
                ClassCode = "Code"
            };
            var resultId = repository.Add(classBatch);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(classBatch.ClassName, newadded.ClassName);
            Assert.AreEqual(classBatch.ClassCode, newadded.ClassCode);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 1;
            var newadded = repository.GetByID(id);
            newadded.ClassName = "Name1";
            newadded.ClassCode = "Code1";

            repository.Update(newadded);

            var updated = repository.GetByID(id);


            Assert.AreEqual(updated.ClassName, newadded.ClassName);
            Assert.AreEqual(updated.ClassCode, newadded.ClassCode);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var classBatch = new ClassBatch
            {
                ClassName = "Name2",
                ClassCode = "Code2"
            };

            var resultId = repository.Add(classBatch);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(classBatch.ClassName, newadded.ClassName);
            Assert.AreEqual(classBatch.ClassCode, newadded.ClassCode);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = repository.GetAll().FirstOrDefault().ClassID;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }
    }
}