﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class CandidateRepositoryTests
    {
    
        private ICandidateRepository repository;
        private ITraineeCandidateRepository repositoryTraineeCandidate;     
        private IRepository<Channel> repositoryChannel = new ChannelRepository();

        [TestInitialize]
        public void Initilize()
        {
            this.repositoryTraineeCandidate = new TraineeCandidateRepository();
            this.repository = new CandidateRepository(repositoryTraineeCandidate); 
        }
        [TestMethod]
        public void AddTest()
        {
            var traineeCandidate = new TraineeCandidate
            {
                FullName = "FullName",
                DateOfBirth = DateTime.Parse("1/1/1996"),
                Gender = "Male",
                UniversityID = "HAUI",
                MajorID = "IT",
                GraduationYear = ("2017"),
                Phone = "129864",
                Email = "rt@mail.com",
                Type = "Candidate",
                ForeignLanguage = "ForeignLanguage",
                Level = "Level",
                Remarks = "Remarks",
                CVFilePath = "CVFilePath"
            };

            var candidate = new Candidate
            {
                //CandidateID = repositoryTraineeCandidate.Add(traineeCandidate),//repositoryTraineeCandidate.GetAll().FirstOrDefault().TraineeCandidateID,
                Status="New",
                ChannelID = repositoryChannel.GetAll().FirstOrDefault().ChannelID,
                TraineeCandidate = traineeCandidate
            };
            var resultId = repository.Add(candidate);

            var newadded = repository.GetByID(resultId);
            
            Assert.AreEqual(candidate.Status, newadded.Status);
            Assert.AreEqual(candidate.ChannelID, newadded.ChannelID);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 11;//repository.GetAll().FirstOrDefault().CandidateID,
            var newadded = repository.GetByID(id);
            newadded.Status = "Status new";

            repository.Update(newadded);

            var updated = repository.GetByID(id);


            Assert.AreEqual(updated.CandidateID, newadded.CandidateID);
            Assert.AreEqual(updated.Status, newadded.Status);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var traineeCandidate = new TraineeCandidate
            {
                FullName = "FullName",
                DateOfBirth = DateTime.Parse("1/1/1996"),
                Gender = "Male",
                UniversityID = "HAUI",
                MajorID = "IT",
                GraduationYear = ("2017"),
                Phone = "012537",
                Email = "t5@mail.com",
                Type = "Candidate",
                ForeignLanguage = "ForeignLanguage",
                Level = "Level",
                Remarks = "Remarks",
                CVFilePath = "CVFilePath"
            };

            var candidate = new Candidate
            {
                //CandidateID = repositoryTraineeCandidate.Add(traineeCandidate),//repositoryTraineeCandidate.GetAll().FirstOrDefault().TraineeCandidateID,
                Status = "New",
                ChannelID = repositoryChannel.GetAll().FirstOrDefault().ChannelID,
                TraineeCandidate = traineeCandidate
            };

            var resultId = repository.Add(candidate);

            var newadded = repository.GetByID(resultId);
            
            Assert.AreEqual(candidate.Status, newadded.Status);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = 11;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }

        [TestMethod]
        public void IsExistTest()
        {
            var candidate = repository.GetByID(1);
            string phone = candidate.TraineeCandidate.Phone;
            string email = candidate.TraineeCandidate.Email;
            var checkExist = repository.IsExist(phone:phone, email:email);
            Assert.AreEqual(checkExist.isEmailExisted, true);
            Assert.AreEqual(checkExist.isPhoneExisted, true);
        }
    }
}