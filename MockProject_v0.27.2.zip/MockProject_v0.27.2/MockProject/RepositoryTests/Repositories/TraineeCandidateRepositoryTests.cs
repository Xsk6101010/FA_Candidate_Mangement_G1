﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class TraineeCandidateRepositoryTests
    {
        private IRepository<TraineeCandidate> repository = new TraineeCandidateRepository();
        
        [TestMethod]
        public void AddTest()
        {
            var traineeCandidate = new TraineeCandidate
            {
                FullName = "FullName",
                DateOfBirth = DateTime.Parse("1/1/1996"),
                Gender = "Male",
                UniversityID = "HAUI",
                MajorID = "IT",
                GraduationYear = ("2017"),
                Phone = "01928374656",
                Email = "full@mail.com",
                Type = "Type",
                ForeignLanguage = "ForeignLanguage",
                Level = "Level",
                Remarks = "Remarks",
                CVFilePath = "CVFilePath"
            };
            var resultId = repository.Add(traineeCandidate);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(traineeCandidate.FullName, newadded.FullName);
            Assert.AreEqual(traineeCandidate.DateOfBirth, newadded.DateOfBirth);
            Assert.AreEqual(traineeCandidate.Gender, newadded.Gender);
            Assert.AreEqual(traineeCandidate.UniversityID, newadded.UniversityID);
            Assert.AreEqual(traineeCandidate.MajorID, newadded.MajorID);
            Assert.AreEqual(traineeCandidate.GraduationYear, newadded.GraduationYear);
            Assert.AreEqual(traineeCandidate.Phone, newadded.Phone);
            Assert.AreEqual(traineeCandidate.Email, newadded.Email);
            Assert.AreEqual(traineeCandidate.Type, newadded.Type);
            Assert.AreEqual(traineeCandidate.ForeignLanguage, newadded.ForeignLanguage);
            Assert.AreEqual(traineeCandidate.Level, newadded.Level);
            Assert.AreEqual(traineeCandidate.Remarks, newadded.Remarks);
            Assert.AreEqual(traineeCandidate.CVFilePath, newadded.CVFilePath);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 11;
            var newadded = repository.GetByID(id);
            newadded.ApplicationDate = DateTime.Parse("1/1/1996");
            newadded.FullName = "FullName";
            newadded.DateOfBirth = DateTime.Parse("1/1/1996");
            newadded.Gender = "Male";
            newadded.UniversityID = "HAUI";
            newadded.MajorID = "IT";
            newadded.GraduationYear = ("2017");
            newadded.Phone = "01928374656";
            newadded.Email = "full@mail.com";
            newadded.Type = "Type";
            newadded.ForeignLanguage = "ForeignLanguage";
            newadded.Level = "Level";
            newadded.Remarks = "Remarks";
            newadded.CVFilePath = "CVFilePath";

            repository.Update(newadded);

            var updated = repository.GetByID(id);


            Assert.AreEqual(updated.FullName, newadded.FullName);
            Assert.AreEqual(updated.DateOfBirth, newadded.DateOfBirth);
            Assert.AreEqual(updated.Gender, newadded.Gender);
            Assert.AreEqual(updated.UniversityID, newadded.UniversityID);
            Assert.AreEqual(updated.MajorID, newadded.MajorID);
            Assert.AreEqual(updated.GraduationYear, newadded.GraduationYear);
            Assert.AreEqual(updated.Phone, newadded.Phone);
            Assert.AreEqual(updated.Email, newadded.Email);
            Assert.AreEqual(updated.Type, newadded.Type);
            Assert.AreEqual(updated.ForeignLanguage, newadded.ForeignLanguage);
            Assert.AreEqual(updated.Level, newadded.Level);
            Assert.AreEqual(updated.Remarks, newadded.Remarks);
            Assert.AreEqual(updated.CVFilePath, newadded.CVFilePath);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var traineeCandidate = new TraineeCandidate
            {
                FullName = "FullName",
                DateOfBirth = DateTime.Parse("1/1/1996"),
                Gender = "Male",
                UniversityID = "HAUI",
                MajorID = "IT",
                GraduationYear = ("2017"),
                Phone = "014656",
                Email = "ful@mail.com",
                Type = "Type",
                ForeignLanguage = "ForeignLanguage",
                Level = "Level",
                Remarks = "Remarks",
                CVFilePath = "CVFilePath"
            };

            var resultId = repository.Add(traineeCandidate);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(traineeCandidate.FullName, newadded.FullName);
            Assert.AreEqual(traineeCandidate.DateOfBirth, newadded.DateOfBirth);
            Assert.AreEqual(traineeCandidate.Gender, newadded.Gender);
            Assert.AreEqual(traineeCandidate.UniversityID, newadded.UniversityID);
            Assert.AreEqual(traineeCandidate.MajorID, newadded.MajorID);
            Assert.AreEqual(traineeCandidate.GraduationYear, newadded.GraduationYear);
            Assert.AreEqual(traineeCandidate.Phone, newadded.Phone);
            Assert.AreEqual(traineeCandidate.Email, newadded.Email);
            Assert.AreEqual(traineeCandidate.Type, newadded.Type);
            Assert.AreEqual(traineeCandidate.ForeignLanguage, newadded.ForeignLanguage);
            Assert.AreEqual(traineeCandidate.Level, newadded.Level);
            Assert.AreEqual(traineeCandidate.Remarks, newadded.Remarks);
            Assert.AreEqual(traineeCandidate.CVFilePath, newadded.CVFilePath);
            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;
            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = 11;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }



        [TestMethod()]
        public void SearchResultTest()
        {
            /* Step 1 : Add one record for test */
            var traineeCandidate = new TraineeCandidate
            {
                FullName = "Tien",
                DateOfBirth = DateTime.Parse("02/02/1987"),
                Gender = "Male",
                UniversityID = "HAUI",
                MajorID = "IT",
                GraduationYear = ("2017"),
                Phone = "014656",
                Email = "hjhjcallme1@mail.com",
                Type = "Type",
                ForeignLanguage = "ForeignLanguage",
                Level = "Level",
                Remarks = "Remarks",
                CVFilePath = "CVFilePath"
            };

            var all = repository.GetAll();
            int total1 = all.Count;
            
            /* Step 2: Add one record */

            /*Step 3: CountAgain */
            /*
            var resultId = repository.Add(traineeCandidate);
            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(traineeCandidate.FullName, newadded.FullName);
            Assert.AreEqual(traineeCandidate.DateOfBirth, newadded.DateOfBirth);
            Assert.AreEqual(traineeCandidate.Gender, newadded.Gender);
            Assert.AreEqual(traineeCandidate.UniversityID, newadded.UniversityID);
            Assert.AreEqual(traineeCandidate.MajorID, newadded.MajorID);
            Assert.AreEqual(traineeCandidate.GraduationYear, newadded.GraduationYear);
            Assert.AreEqual(traineeCandidate.Phone, newadded.Phone);
            Assert.AreEqual(traineeCandidate.Email, newadded.Email);
            Assert.AreEqual(traineeCandidate.Type, newadded.Type);
            Assert.AreEqual(traineeCandidate.ForeignLanguage, newadded.ForeignLanguage);
            Assert.AreEqual(traineeCandidate.Level, newadded.Level);
            Assert.AreEqual(traineeCandidate.Remarks, newadded.Remarks);
            Assert.AreEqual(traineeCandidate.CVFilePath, newadded.CVFilePath);
            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;
            Assert.AreEqual(total1 + 1, total2);
            */




        }

    }
}