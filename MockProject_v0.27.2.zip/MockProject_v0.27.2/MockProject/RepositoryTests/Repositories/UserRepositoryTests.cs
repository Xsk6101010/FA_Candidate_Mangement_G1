﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class UserRepositoryTests
    {
        private IUserRepository repository = new UserRepository();
        
        [TestMethod()]
        public void AddTest()
        {
            var user = new User
            {
                Username = "Test1",
                Password = "123",
                Role = "candidate"
            };
            var resultId = repository.Add(user);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(user.Username, newadded.Username);
            Assert.AreEqual(user.Password, newadded.Password);
            Assert.AreEqual(user.Role, newadded.Role);
        }
        
        [TestMethod]
        public void UpdateTest()
        {
            var id = "Test1";
            var newadded = repository.GetByID(id);
            newadded.Password = "222";
            newadded.Role = "candidate";

            repository.Update(newadded);

            var updated = repository.GetByID(id);

            Assert.AreEqual(newadded.Username, updated.Username);
            Assert.AreEqual(newadded.Password, updated.Password);
            Assert.AreEqual(newadded.Role, updated.Role);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var user = new User
            {
                Username = "Test2",
                Password = "123",
                Role = "candidate"
            };

            var resultId = repository.Add(user);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(user.Username, newadded.Username);
            Assert.AreEqual(user.Password, newadded.Password);
            Assert.AreEqual(user.Role, newadded.Role);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = "Test2";
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }
        string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }
        [TestMethod]
        public void CheckLoginTest()
        {
            var username = "ngocpt5";
            var password = CreateMD5("123456");
            repository.CheckLogin(username,password);
            var newadded = repository.GetByID(username);
            Assert.AreEqual(password, newadded.Password);
        }
    }
}