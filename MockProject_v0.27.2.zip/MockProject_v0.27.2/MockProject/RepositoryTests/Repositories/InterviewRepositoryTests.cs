﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class InterviewRepositoryTests
    {
        private IInterviewRepository repository = new InterviewRepository();
        private ICandidateRepository repositoryCandidate;
        [TestInitialize]
        public void Initilize()
        {
            ITraineeCandidateRepository repositoryTraineeCandidate = new TraineeCandidateRepository();
            this.repositoryCandidate = new CandidateRepository(repositoryTraineeCandidate);
        }
        [TestMethod]
        public void AddTest()
        {
            var interview = new Interview
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Time = 1,
                Date = DateTime.Parse("1/1/2018"),
                Interviewer = "Interviewer",
                Comments = "Comments",
                Result = "Result",
                Remarks = "Remarks"
            };
            var resultId = repository.Add(interview);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(interview.CandidateID, newadded.CandidateID);
            Assert.AreEqual(interview.Time, newadded.Time);
            Assert.AreEqual(interview.Date, newadded.Date);
            Assert.AreEqual(interview.Interviewer, newadded.Interviewer);
            Assert.AreEqual(interview.Comments, newadded.Comments);
            Assert.AreEqual(interview.Result, newadded.Result);
            Assert.AreEqual(interview.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 1;
            var newadded = repository.GetByID(id);
            newadded.CandidateID = 1;
            newadded.Time = 1;
            newadded.Date = DateTime.Parse("1/1/2018");
            newadded.Interviewer = "Interviewer";
            newadded.Comments = "Comments";
            newadded.Result = "Result";
            newadded.Remarks = "Remarks";

            repository.Update(newadded);

            var updated = repository.GetByID(id);


            Assert.AreEqual(updated.CandidateID, newadded.CandidateID);
            Assert.AreEqual(updated.Time, newadded.Time);
            Assert.AreEqual(updated.Date, newadded.Date);
            Assert.AreEqual(updated.Interviewer, newadded.Interviewer);
            Assert.AreEqual(updated.Comments, newadded.Comments);
            Assert.AreEqual(updated.Result, newadded.Result);
            Assert.AreEqual(updated.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var interview = new Interview
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Time = 1,
                Date = DateTime.Parse("1/1/2018"),
                Interviewer = "Interviewer",
                Comments = "Comments",
                Result = "Result",
                Remarks = "Remarks"
            };

            var resultId = repository.Add(interview);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(interview.CandidateID, newadded.CandidateID);
            Assert.AreEqual(interview.Time, newadded.Time);
            Assert.AreEqual(interview.Date, newadded.Date);
            Assert.AreEqual(interview.Interviewer, newadded.Interviewer);
            Assert.AreEqual(interview.Comments, newadded.Comments);
            Assert.AreEqual(interview.Result, newadded.Result);
            Assert.AreEqual(interview.Remarks, newadded.Remarks);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = repository.GetAll().FirstOrDefault().InterviewID;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }

        [TestMethod]
        public void GetByCadidateIDTest()
        {
            var resultId = repositoryCandidate.GetAll().FirstOrDefault().CandidateID;

            var all = repository.GetByCadidateID(resultId);
            int total1 = all.Count;
            var interview = new Interview
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Time = 1,
                Date = DateTime.Parse("1/1/2018"),
                Interviewer = "Interviewer",
                Comments = "Comments",
                Result = "Result",
                Remarks = "Remarks"
            };

            var offers = repository.Add(interview);

            var newadded = repository.GetByID(offers);

            Assert.AreEqual(interview.CandidateID, newadded.CandidateID);
            Assert.AreEqual(interview.Time, newadded.Time);
            Assert.AreEqual(interview.Date, newadded.Date);
            Assert.AreEqual(interview.Interviewer, newadded.Interviewer);
            Assert.AreEqual(interview.Comments, newadded.Comments);
            Assert.AreEqual(interview.Result, newadded.Result);
            Assert.AreEqual(interview.Remarks, newadded.Remarks);

            var allafteradded = repository.GetByCadidateID(resultId);
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);
        }
    }
}