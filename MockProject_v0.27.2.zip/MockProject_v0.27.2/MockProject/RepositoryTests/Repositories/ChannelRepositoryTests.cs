﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using Model;

namespace Repository.Tests
{
    [TestClass()]
    public class ChannelRepositoryTests
    {
        private IRepository<Channel> repository = new ChannelRepository();
       
        [TestMethod]
        public void AddTest()
        {
            var channel = new Channel
            {
                Remarks = "Remarks",
                ChannelName = "ChannelName"
            };
            var resultId = repository.Add(channel);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(channel.Remarks, newadded.Remarks);
            Assert.AreEqual(channel.ChannelName, newadded.ChannelName);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 7;// repository.GetAll().FirstOrDefault().ChannelID;
            var newadded = repository.GetByID(id);
            newadded.Remarks = "Remarks1";
            newadded.ChannelName = "ChannelName";

            repository.Update(newadded);

            var updated = repository.GetByID(id);

            Assert.AreEqual(updated.ChannelName, newadded.ChannelName);
            Assert.AreEqual(updated.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var channel = new Channel
            {
                Remarks = "Remarks",
                ChannelName = "ChannelName"
            };

            var resultId = repository.Add(channel);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(channel.Remarks, newadded.Remarks);
            Assert.AreEqual(channel.ChannelName, newadded.ChannelName);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = 7;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }
    }
}