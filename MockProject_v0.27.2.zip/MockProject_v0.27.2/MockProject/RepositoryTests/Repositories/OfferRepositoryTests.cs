﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Tests
{
    [TestClass()]
    public class OfferRepositoryTests
    {
        private IOfferRepository repository = new OfferRepository();
        private ICandidateRepository repositoryCandidate;// = new CandidateRepository();
        [TestInitialize]
        public void Initilize()
        {
            ITraineeCandidateRepository repositoryTraineeCandidate = new TraineeCandidateRepository();
            this.repositoryCandidate = new CandidateRepository(repositoryTraineeCandidate);
        }
        [TestMethod]
        public void AddTest()
        {
            var offer = new Offer
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Jobrank = 1,
                Technology = "Technology",
                ContractType = "ContractType",
                OfferSalary = decimal.Parse("8.5"),
                Remarks = "Remarks"
            };
            var resultId = repository.Add(offer);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(offer.CandidateID, newadded.CandidateID);
            Assert.AreEqual(offer.Jobrank, newadded.Jobrank);
            Assert.AreEqual(offer.Technology, newadded.Technology);
            Assert.AreEqual(offer.ContractType, newadded.ContractType);
            Assert.AreEqual(offer.OfferSalary, newadded.OfferSalary);
            Assert.AreEqual(offer.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void UpdateTest()
        {
            var id = 1;
            var newadded = repository.GetByID(id);
            newadded.CandidateID = 1;
            newadded.Jobrank = 1;
            newadded.Technology = "Technology";
            newadded.ContractType = "ContractType";
            newadded.OfferSalary = decimal.Parse("8.5");
            newadded.Remarks = "Remarks";

            repository.Update(newadded);

            var updated = repository.GetByID(id);


            Assert.AreEqual(updated.CandidateID, newadded.CandidateID);
            Assert.AreEqual(updated.Jobrank, newadded.Jobrank);
            Assert.AreEqual(updated.Technology, newadded.Technology);
            Assert.AreEqual(updated.ContractType, newadded.ContractType);
            Assert.AreEqual(updated.OfferSalary, newadded.OfferSalary);
            Assert.AreEqual(updated.Remarks, newadded.Remarks);
        }

        [TestMethod]
        public void GetAllTest()
        {
            var all = repository.GetAll();
            int total1 = all.Count;
            var offer = new Offer
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Jobrank = 1,
                Technology = "Technology",
                ContractType = "ContractType",
                OfferSalary = decimal.Parse("8.5"),
                Remarks = "Remarks"
            };

            var resultId = repository.Add(offer);

            var newadded = repository.GetByID(resultId);

            Assert.AreEqual(offer.CandidateID, newadded.CandidateID);
            Assert.AreEqual(offer.Jobrank, newadded.Jobrank);
            Assert.AreEqual(offer.Technology, newadded.Technology);
            Assert.AreEqual(offer.ContractType, newadded.ContractType);
            Assert.AreEqual(offer.OfferSalary, newadded.OfferSalary);
            Assert.AreEqual(offer.Remarks, newadded.Remarks);

            var allafteradded = repository.GetAll();
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);

        }
        [TestMethod]
        public void DeleteTest()
        {
            var resultId = repository.GetAll().FirstOrDefault().OfferID;
            repository.Delete(resultId);

            var deleted = repository.GetByID(resultId);
            Assert.IsNull(deleted);
        }

        [TestMethod]
        public void GetByForeignKeyIDTest()
        {
            var resultId = repositoryCandidate.GetAll().FirstOrDefault().CandidateID;

            var all = repository.GetByForeignKeyID(resultId);
            int total1 = all.Count;
            var offer = new Offer
            {
                CandidateID = repositoryCandidate.GetAll().FirstOrDefault().CandidateID,
                Jobrank = 1,
                Technology = "Technology",
                ContractType = "ContractType1",
                OfferSalary = decimal.Parse("9.5"),
                Remarks = "Remarks1"
            };

            var offers = repository.Add(offer);

            var newadded = repository.GetByID(offers);

            Assert.AreEqual(offer.CandidateID, newadded.CandidateID);
            Assert.AreEqual(offer.Jobrank, newadded.Jobrank);
            Assert.AreEqual(offer.Technology, newadded.Technology);
            Assert.AreEqual(offer.ContractType, newadded.ContractType);
            Assert.AreEqual(offer.OfferSalary, newadded.OfferSalary);
            Assert.AreEqual(offer.Remarks, newadded.Remarks);

            var allafteradded = repository.GetByForeignKeyID(resultId);
            int total2 = allafteradded.Count;

            Assert.AreEqual(total1 + 1, total2);
        }
    }
}